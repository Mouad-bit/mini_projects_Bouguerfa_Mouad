<template>
  <div class="container">
    <div class="header">
      <h2>Projects</h2>
      <button class="btn primary" @click="showAddDialog = true">
        ➕ Add Project
      </button>
    </div>

    <div class="projects-grid">
      <div class="project-card" v-for="project in projects" :key="project.id">
        <img
          :src="project.imageUrl || 'https://via.placeholder.com/400x200'"
          alt="Project Image"
        />
        <h3>{{ project.title }}</h3>
        <p>{{ project.description }}</p>

        <div class="tags">
          <span v-for="tech in project.technologies" :key="tech" class="chip">
            {{ tech }}
          </span>
        </div>

        <div class="actions">
          <a
            v-if="project.githubUrl"
            :href="project.githubUrl"
            target="_blank"
            class="btn small"
          >
            🔗 GitHub
          </a>
          <button class="icon-btn" @click="editProject(project)">✏️</button>
          <button class="icon-btn" @click="deleteProject(project)">🗑️</button>
        </div>
      </div>
    </div>

    <!-- Add/Edit Dialog -->
    <div class="dialog-overlay" v-if="showAddDialog">
      <div class="dialog">
        <h3>{{ formTitle }}</h3>

        <form @submit.prevent="save">
          <input
            v-model="editedItem.title"
            placeholder="Project Title"
            required
          />
          <textarea
            v-model="editedItem.description"
            placeholder="Description"
            required
          ></textarea>
          <input
            v-model="editedItem.technologies"
            placeholder="Technologies (comma-separated)"
            @blur="parseTechnologies"
          />
          <input v-model="editedItem.githubUrl" placeholder="GitHub URL" />
          <input type="file" @change="onFileChange" accept="image/*" />

          <div class="form-actions">
            <button type="button" class="btn" @click="close">Cancel</button>
            <button type="submit" class="btn primary">Save</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script>
import { db, storage, auth } from "../firebase/config";
import {
  collection,
  addDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  doc,
  query,
  where,
} from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { onAuthStateChanged } from "firebase/auth";

export default {
  name: "UserProjects",
  data() {
    return {
      showAddDialog: false,
      editedIndex: -1,
      editedItem: {
        title: "",
        description: "",
        technologies: [],
        githubUrl: "",
        image: null,
        imageUrl: "",
      },
      defaultItem: {
        title: "",
        description: "",
        technologies: [],
        githubUrl: "",
        image: null,
        imageUrl: "",
      },
      projects: [],
      currentUser: null,
      loading: false,
    };
  },
  created() {
    this.unsubscribe = onAuthStateChanged(auth, (user) => {
      this.currentUser = user;
      if (user) {
        this.fetchProjects();
      } else {
        this.projects = [];
      }
    });
  },
  beforeUnmount() {
    if (this.unsubscribe) this.unsubscribe();
  },
  methods: {
    async fetchProjects() {
      if (!this.currentUser) return;

      try {
        const q = query(
          collection(db, "projects"),
          where("userId", "==", this.currentUser.uid)
        );
        const snapshot = await getDocs(q);
        this.projects = snapshot.docs
          .map((doc) => ({
            id: doc.id,
            ...doc.data(),
            date: doc.data().date || new Date().toISOString(),
          }))
          .sort((a, b) => {
            const timeA = a.timestamp || new Date(a.date).getTime();
            const timeB = b.timestamp || new Date(b.date).getTime();
            return timeB - timeA;
          });
      } catch (error) {
        console.error("Error fetching projects:", error);
      }
    },
    async save() {
      if (!this.currentUser) {
        alert("Please log in to save projects");
        return;
      }

      if (!this.editedItem.title || !this.editedItem.description) {
        alert("Please fill in all required fields");
        return;
      }

      try {
        this.loading = true;
        let imageUrl = this.editedItem.imageUrl;

        if (this.editedItem.image) {
          imageUrl = await this.uploadImage(this.editedItem.image);
        }

        const now = new Date();
        const projectData = {
          title: this.editedItem.title,
          description: this.editedItem.description,
          technologies: this.editedItem.technologies || [],
          githubUrl: this.editedItem.githubUrl || "",
          imageUrl: imageUrl || "",
          userId: this.currentUser.uid,
          createdAt: now.toISOString(),
          date: now.toISOString(),
          timestamp: now.getTime(),
        };

        if (this.editedIndex > -1) {
          const projectRef = doc(db, "projects", this.editedItem.id);
          await updateDoc(projectRef, {
            ...projectData,
            updatedAt: now.toISOString(),
          });

          Object.assign(this.projects[this.editedIndex], {
            ...projectData,
            id: this.editedItem.id,
          });
        } else {
          const projectsRef = collection(db, "projects");
          const docRef = await addDoc(projectsRef, projectData);
          this.projects.push({
            ...projectData,
            id: docRef.id,
          });
        }

        await this.fetchProjects();
        this.close();
        alert("Project saved successfully!");
      } catch (error) {
        console.error("Error saving project:", error);
        alert("Error saving project: " + error.message);
      } finally {
        this.loading = false;
      }
    },
    async uploadImage(file) {
      if (!file || !this.currentUser) return null;
      try {
        const storageRef = ref(
          storage,
          `project-images/${this.currentUser.uid}/${Date.now()}_${file.name}`
        );
        const snapshot = await uploadBytes(storageRef, file);
        return await getDownloadURL(snapshot.ref);
      } catch (error) {
        console.error("Image upload error:", error);
        alert("Image upload failed");
        return null;
      }
    },
    editProject(project) {
      this.editedIndex = this.projects.indexOf(project);
      this.editedItem = Object.assign({}, project);
      this.showAddDialog = true;
    },
    async deleteProject(project) {
      if (confirm("Are you sure you want to delete this project?")) {
        try {
          await deleteDoc(doc(db, "projects", project.id));
          this.projects = this.projects.filter((p) => p.id !== project.id);
        } catch (error) {
          console.error("Error deleting project:", error);
        }
      }
    },
    close() {
      this.showAddDialog = false;
      this.$nextTick(() => {
        this.editedItem = Object.assign({}, this.defaultItem);
        this.editedIndex = -1;
      });
    },
  },
};
</script>

<style scoped>
.container {
  padding: 16px;
}
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.projects-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
}
.project-card {
  border: 1px solid #ddd;
  border-radius: 8px;
  width: 100%;
  max-width: 400px;
  padding: 16px;
  transition: transform 0.2s;
}
.project-card:hover {
  transform: translateY(-5px);
}
.project-card img {
  width: 100%;
  height: 200px;
  object-fit: cover;
  border-radius: 4px;
}
.tags {
  margin: 8px 0;
}
.chip {
  background-color: #eee;
  padding: 4px 8px;
  margin: 2px;
  display: inline-block;
  border-radius: 16px;
  font-size: 0.8rem;
}
.actions {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  margin-top: 8px;
}
.icon-btn {
  background: none;
  border: none;
  cursor: pointer;
  font-size: 1rem;
}
.dialog-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.4);
  display: flex;
  justify-content: center;
  align-items: center;
}
.dialog {
  background: white;
  padding: 24px;
  border-radius: 8px;
  width: 90%;
  max-width: 600px;
}
.dialog input,
.dialog textarea {
  width: 100%;
  margin-bottom: 12px;
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 4px;
}
.form-actions {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}
.btn {
  padding: 8px 12px;
  border: none;
  border-radius: 4px;
  background: #ccc;
  cursor: pointer;
}
.btn.primary {
  background: #1976d2;
  color: white;
}
.btn.small {
  font-size: 0.9rem;
  padding: 4px 8px;
}
</style>
