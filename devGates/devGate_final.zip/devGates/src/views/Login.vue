<template>
  <div class="container">
    <div class="login-card">
      <div class="toolbar">Login to DevGate</div>
      <div class="card-text">
        <form @submit.prevent="login">
          <div class="form-group">
            <label for="email">Email</label>
            <input v-model="email" type="email" id="email" required />
          </div>

          <div class="form-group">
            <label for="password">Password</label>
            <input v-model="password" type="password" id="password" required />
          </div>
        </form>
      </div>
      <div class="card-actions">
        <button class="btn primary" @click="login">Login</button>
        <button class="btn secondary" @click="signInWithGoogle">
          Login with Google
        </button>
      </div>
      <div class="card-actions">
        <router-link to="/register"
          >Don't have an account? Register</router-link
        >
      </div>
    </div>
  </div>
</template>

<script>
import { auth } from "../firebase/config";
import {
  signInWithEmailAndPassword,
  GoogleAuthProvider,
  signInWithPopup,
} from "firebase/auth";

export default {
  name: "UserLogin",
  data() {
    return {
      email: "",
      password: "",
    };
  },
  methods: {
    async login() {
      try {
        const userCredential = await signInWithEmailAndPassword(
          auth,
          this.email,
          this.password
        );
        localStorage.setItem("user", JSON.stringify(userCredential.user));
        this.$router.push("/dashboard").then(() => {
          window.location.reload();
        });
      } catch (error) {
        console.error("Error logging in:", error);
        alert("Error logging in: " + error.message);
      }
    },
    async signInWithGoogle() {
      try {
        const provider = new GoogleAuthProvider();
        const result = await signInWithPopup(auth, provider);
        localStorage.setItem("user", JSON.stringify(result.user));
        this.$router.push("/dashboard").then(() => {
          window.location.reload();
        });
      } catch (error) {
        console.error("Error signing in with Google:", error);
        alert("Error signing in with Google: " + error.message);
      }
    },
  },
};
</script>

<style>
.container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #f5f5f5;
}

.login-card {
  width: 100%;
  max-width: 400px;
  background-color: white;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  padding: 20px;
  border-radius: 8px;
  box-sizing: border-box;
}

.toolbar {
  font-size: 20px;
  background-color: #1976d2;
  color: white;
  padding: 12px;
  text-align: center;
  border-radius: 6px 6px 0 0;
}

.form-group {
  margin-bottom: 16px;
}

label {
  display: block;
  margin-bottom: 6px;
  font-weight: bold;
}

input[type="email"],
input[type="password"] {
  width: 100%;
  padding: 10px;
  box-sizing: border-box;
  border: 1px solid #ccc;
  border-radius: 4px;
}

.card-actions {
  margin-top: 16px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
}

.btn {
  padding: 10px 16px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  color: white;
}

.btn.primary {
  background-color: #1976d2;
}

.btn.secondary {
  background-color: #9c27b0;
}

router-link {
  color: #1976d2;
  text-decoration: none;
  font-size: 0.9em;
}
</style>
