<template>
  <div class="register-container">
    <div class="register-card">
      <h2 class="register-title">Register</h2>
      <form @submit.prevent="register" class="register-form">
        <label>
          Email:
          <input type="email" v-model="email" required />
        </label>

        <label>
          Password:
          <input type="password" v-model="password" required />
        </label>

        <label>
          Confirm Password:
          <input type="password" v-model="confirmPassword" required />
        </label>

        <button type="submit">Register</button>
      </form>

      <div class="login-link">
        <router-link to="/login">Already have an account? Login</router-link>
      </div>
    </div>
  </div>
</template>

<script>
import { auth } from "../firebase/config";
import { createUserWithEmailAndPassword } from "firebase/auth";

export default {
  name: "RegisterView",
  data() {
    return {
      email: "",
      password: "",
      confirmPassword: "",
    };
  },
  methods: {
    async register() {
      if (this.password !== this.confirmPassword) {
        alert("Passwords do not match");
        return;
      }

      try {
        console.log("Attempting to register with email:", this.email);
        const userCredential = await createUserWithEmailAndPassword(
          auth,
          this.email,
          this.password
        );
        console.log("Registration successful:", userCredential.user);

        const userData = {
          uid: userCredential.user.uid,
          email: userCredential.user.email,
        };
        localStorage.setItem("user", JSON.stringify(userData));
        this.$router.push("/dashboard");
      } catch (error) {
        console.error("Detailed registration error:", {
          code: error.code,
          message: error.message,
          name: error.name,
        });

        let errorMessage = "Error registering: ";
        switch (error.code) {
          case "auth/network-request-failed":
            errorMessage +=
              "Network error. Please check your internet connection and try again.";
            break;
          case "auth/email-already-in-use":
            errorMessage += "This email is already registered.";
            break;
          case "auth/invalid-email":
            errorMessage += "The email address is invalid.";
            break;
          case "auth/operation-not-allowed":
            errorMessage += "Email/password accounts are not enabled.";
            break;
          case "auth/weak-password":
            errorMessage += "The password is too weak.";
            break;
          default:
            errorMessage += error.message;
        }
        alert(errorMessage);
      }
    },
  },
};
</script>

<style scoped>
.register-container {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  background: #f5f5f5;
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

.register-card {
  background: white;
  padding: 2rem;
  border-radius: 10px;
  width: 100%;
  max-width: 400px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  margin: 20px;
}

.register-title {
  margin-bottom: 1rem;
  text-align: center;
  color: #333;
  font-size: 1.5rem;
}

.register-form {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.register-form label {
  display: block;
  margin-bottom: 0.5rem;
  color: #333;
  font-weight: 500;
}

.register-form input {
  width: 100%;
  padding: 0.75rem;
  margin-top: 0.25rem;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  font-size: 1rem;
  transition: border-color 0.3s ease;
}

.register-form input:focus {
  outline: none;
  border-color: #1976d2;
}

button {
  width: 100%;
  padding: 0.75rem;
  background-color: #1976d2;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-weight: bold;
  font-size: 1rem;
  transition: background-color 0.3s ease;
  margin-top: 1rem;
}

button:hover {
  background-color: #1565c0;
}

.login-link {
  text-align: center;
  margin-top: 1.5rem;
  color: #666;
}

.login-link a {
  color: #1976d2;
  text-decoration: none;
  font-weight: 500;
}

.login-link a:hover {
  text-decoration: underline;
}
</style>
