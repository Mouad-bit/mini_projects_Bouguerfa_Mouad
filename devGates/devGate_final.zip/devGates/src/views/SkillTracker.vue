<template>
  <div class="container">
    <div class="card">
      <div class="card-header">
        <h2>Skills</h2>
        <button class="btn" @click="showAddDialog = true">Add Skill</button>
      </div>
      <div class="card-body">
        <table class="table">
          <thead>
            <tr>
              <th>Skill Name</th>
              <th>Level</th>
              <th>Date Acquired</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="skill in skills" :key="skill.id">
              <td>{{ skill.name }}</td>
              <td>
                <span :class="['chip', getLevelColor(skill.level)]">
                  {{ skill.level }}
                </span>
              </td>
              <td>{{ skill.date }}</td>
              <td>
                <button class="icon-btn" @click="editSkill(skill)">✏️</button>
                <button class="icon-btn" @click="deleteSkill(skill)">🗑️</button>
              </td>
            </tr>
          </tbody>
        </table>
        <p v-if="loading">Loading...</p>
      </div>
    </div>

    <!-- Add/Edit Skill Dialog -->
    <div v-if="showAddDialog" class="dialog">
      <div class="dialog-content">
        <h3>{{ formTitle }}</h3>
        <label>
          Skill Name:
          <input v-model="editedItem.name" type="text" required />
        </label>
        <label>
          Level:
          <select v-model="editedItem.level" required>
            <option v-for="level in levels" :key="level" :value="level">
              {{ level }}
            </option>
          </select>
        </label>
        <label>
          Date Acquired:
          <input v-model="editedItem.date" type="date" required />
        </label>
        <div class="dialog-actions">
          <button class="btn" @click="close">Cancel</button>
          <button class="btn" @click="save">Save</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { db, auth } from "../firebase/config";
import {
  collection,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  getDocs,
  query,
  where,
} from "firebase/firestore";

export default {
  name: "SkillTracker",
  data() {
    return {
      loading: false,
      showAddDialog: false,
      editedIndex: -1,
      editedItem: {
        name: "",
        level: "Beginner",
        date: new Date().toISOString().substr(0, 10),
      },
      defaultItem: {
        name: "",
        level: "Beginner",
        date: new Date().toISOString().substr(0, 10),
      },
      headers: ["Skill Name", "Level", "Date Acquired", "Actions"],
      skills: [],
      levels: ["Beginner", "Intermediate", "Advanced"],
    };
  },
  computed: {
    formTitle() {
      return this.editedIndex === -1 ? "New Skill" : "Edit Skill";
    },
  },
  async created() {
    // Wait for user authentication state to be confirmed
    const unsubscribe = auth.onAuthStateChanged(async (user) => {
      if (user) {
        await this.fetchSkills();
      } else {
        console.error("No authenticated user found");
      }
      unsubscribe(); // Unsubscribe to avoid multiple calls
    });
  },
  methods: {
    getLevelColor(level) {
      const colors = {
        Beginner: "blue",
        Intermediate: "orange",
        Advanced: "green",
      };
      return colors[level] || "grey";
    },
    async fetchSkills() {
      this.loading = true;
      try {
        const currentUser = auth.currentUser;
        if (!currentUser) {
          throw new Error("No authenticated user found");
        }

        const skillsQuery = query(
          collection(db, "skills"),
          where("userId", "==", currentUser.uid)
        );
        const querySnapshot = await getDocs(skillsQuery);
        this.skills = querySnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
      } catch (error) {
        alert(`Error fetching skills: ${error.message}`);
      } finally {
        this.loading = false;
      }
    },
    editSkill(item) {
      this.editedIndex = this.skills.indexOf(item);
      this.editedItem = Object.assign({}, item);
      this.showAddDialog = true;
    },
    async deleteSkill(item) {
      if (confirm("Are you sure you want to delete this skill?")) {
        try {
          const currentUser = auth.currentUser;
          if (!currentUser) throw new Error("No authenticated user found");
          await deleteDoc(doc(db, "skills", item.id));
          await this.fetchSkills();
        } catch (error) {
          alert(`Error deleting skill: ${error.message}`);
        }
      }
    },
    close() {
      this.showAddDialog = false;
      this.$nextTick(() => {
        this.editedItem = Object.assign({}, this.defaultItem);
        this.editedIndex = -1;
      });
    },
    async save() {
      try {
        const currentUser = auth.currentUser;
        if (!currentUser) throw new Error("No authenticated user found");

        const skillData = {
          ...this.editedItem,
          userId: currentUser.uid,
        };

        if (this.editedIndex > -1) {
          await updateDoc(doc(db, "skills", this.editedItem.id), skillData);
        } else {
          await addDoc(collection(db, "skills"), skillData);
        }

        await this.fetchSkills();
        this.close();
      } catch (error) {
        alert(`Error saving skill: ${error.message}`);
      }
    },
  },
};
</script>

<style scoped>
.card {
  border: 1px solid #ddd;
  border-radius: 8px;
  overflow: hidden;
}
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: #f5f5f5;
  padding: 1rem;
}
.card-body {
  padding: 1rem;
}
.table {
  width: 100%;
  border-collapse: collapse;
}
.table th,
.table td {
  padding: 0.75rem;
  border: 1px solid #ddd;
  text-align: left;
}
.btn {
  padding: 0.5rem 1rem;
  background: #1976d2;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
.btn:hover {
  background: #125a9c;
}
.icon-btn {
  background: none;
  border: none;
  cursor: pointer;
  font-size: 1.2rem;
}
.chip {
  padding: 0.25rem 0.75rem;
  border-radius: 999px;
  color: white;
  font-weight: bold;
}
.blue {
  background-color: #2196f3;
}
.orange {
  background-color: #ff9800;
}
.green {
  background-color: #4caf50;
}
.dialog {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.4);
  display: flex;
  align-items: center;
  justify-content: center;
}
.dialog-content {
  background: white;
  padding: 2rem;
  border-radius: 8px;
  width: 400px;
  display: flex;
  flex-direction: column;
  gap: 1rem;
}
.dialog-content input,
.dialog-content select {
  border: 1px solid rgba(0, 0, 0, 0.4);
  margin-left: 10px;
  padding: 2px;
}
.dialog-actions {
  display: flex;
  justify-content: flex-end;
  gap: 1rem;
}
</style>
