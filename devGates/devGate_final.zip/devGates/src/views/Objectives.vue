<template>
  <div class="container">
    <div class="header">
      <h2>Technical Objectives</h2>
      <button class="add-btn" @click="showAddDialog = true">
        + Add Objective
      </button>
    </div>

    <div v-for="objective in objectives" :key="objective.id" class="card">
      <div class="card-header">
        <h3>{{ objective.title }}</h3>
        <span :class="'status ' + getStatusColor(objective.status)">
          {{ objective.status }}
        </span>
      </div>
      <p>{{ objective.description }}</p>

      <div class="progress-bar">
        <div
          :style="{
            width: objective.progress + '%',
            backgroundColor: getProgressColor(objective.progress),
          }"
        >
          {{ Math.ceil(objective.progress) }}%
        </div>
      </div>

      <div class="skills">
        <span
          class="skill"
          v-for="skill in objective.relatedSkills"
          :key="skill"
          >{{ skill }}</span
        >
      </div>

      <div class="due-date">📅 Due: {{ formatDate(objective.dueDate) }}</div>

      <div class="actions">
        <button @click="editObjective(objective)">✏️ Edit</button>
        <button @click="deleteObjective(objective)">🗑️ Delete</button>
      </div>
    </div>

    <!-- Dialog -->
    <div v-if="showAddDialog" class="dialog">
      <div class="dialog-content">
        <h3>{{ formTitle }}</h3>
        <input
          v-model="editedItem.title"
          placeholder="Objective Title"
          required
        />
        <textarea
          v-model="editedItem.description"
          placeholder="Description"
          required
        ></textarea>
        <select v-model="editedItem.status">
          <option v-for="status in statusOptions" :key="status" :value="status">
            {{ status }}
          </option>
        </select>
        <input type="range" v-model="editedItem.progress" min="0" max="100" />
        <input v-model="editedItem.dueDate" type="date" required />
        <input
          v-model="editedItem.relatedSkillsString"
          placeholder="Skills (comma-separated)"
        />

        <div class="dialog-actions">
          <button @click="close">Cancel</button>
          <button @click="save">Save</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { db } from "../firebase/config";
import {
  collection,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  getDocs,
  query,
  where,
} from "firebase/firestore";

export default {
  name: "UserObjectives",
  data() {
    return {
      loading: false,
      showAddDialog: false,
      editedIndex: -1,
      editedItem: {
        title: "",
        description: "",
        status: "In Progress",
        progress: 0,
        relatedSkills: [],
        relatedSkillsString: "",
        dueDate: new Date().toISOString().substr(0, 10),
      },
      defaultItem: {
        title: "",
        description: "",
        status: "In Progress",
        progress: 0,
        relatedSkills: [],
        relatedSkillsString: "",
        dueDate: new Date().toISOString().substr(0, 10),
      },
      objectives: [],
      statusOptions: ["In Progress", "Completed", "On Hold"],
    };
  },
  computed: {
    formTitle() {
      return this.editedIndex === -1 ? "New Objective" : "Edit Objective";
    },
  },
  async created() {
    await this.fetchObjectives();
  },
  methods: {
    getStatusColor(status) {
      return (
        {
          "In Progress": "blue",
          Completed: "green",
          "On Hold": "orange",
        }[status] || "gray"
      );
    },
    getProgressColor(progress) {
      if (progress >= 100) return "green";
      if (progress >= 50) return "blue";
      return "orange";
    },
    formatDate(date) {
      return new Date(date).toLocaleDateString();
    },
    async fetchObjectives() {
      this.loading = true;
      try {
        const user = JSON.parse(localStorage.getItem("user"));
        const objectivesQuery = query(
          collection(db, "objectives"),
          where("userId", "==", user.uid)
        );
        const querySnapshot = await getDocs(objectivesQuery);
        this.objectives = querySnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
      } catch (error) {
        console.error("Error fetching objectives:", error);
      } finally {
        this.loading = false;
      }
    },
    editObjective(objective) {
      this.editedIndex = this.objectives.indexOf(objective);
      this.editedItem = {
        ...objective,
        relatedSkillsString: objective.relatedSkills.join(", "),
      };
      this.showAddDialog = true;
    },
    async deleteObjective(objective) {
      if (confirm("Are you sure you want to delete this objective?")) {
        try {
          await deleteDoc(doc(db, "objectives", objective.id));
          await this.fetchObjectives();
        } catch (error) {
          console.error("Error deleting objective:", error);
        }
      }
    },
    close() {
      this.showAddDialog = false;
      this.$nextTick(() => {
        this.editedItem = { ...this.defaultItem };
        this.editedIndex = -1;
      });
    },
    async save() {
      try {
        const user = JSON.parse(localStorage.getItem("user"));
        const objectiveData = {
          ...this.editedItem,
          userId: user.uid,
          relatedSkills: this.editedItem.relatedSkillsString
            .split(",")
            .map((s) => s.trim()),
        };

        if (this.editedIndex > -1) {
          await updateDoc(
            doc(db, "objectives", this.editedItem.id),
            objectiveData
          );
        } else {
          await addDoc(collection(db, "objectives"), objectiveData);
        }
        await this.fetchObjectives();
        this.close();
      } catch (error) {
        console.error("Error saving objective:", error);
      }
    },
  },
};
</script>

<style scoped>
.container {
  max-width: 900px;
  margin: auto;
  padding: 20px;
}
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.card {
  background: #fff;
  padding: 20px;
  border-radius: 10px;
  margin-bottom: 20px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.status {
  padding: 5px 10px;
  border-radius: 5px;
  color: #fff;
}
.status.blue {
  background: #1976d2;
}
.status.green {
  background: #4caf50;
}
.status.orange {
  background: #ff9800;
}

.progress-bar {
  background: #e0e0e0;
  border-radius: 5px;
  overflow: hidden;
  height: 25px;
  margin-top: 10px;
}
.progress-bar > div {
  color: white;
  text-align: center;
  height: 100%;
  line-height: 25px;
  transition: width 0.3s ease;
}
.skills {
  margin-top: 10px;
}
.skill {
  display: inline-block;
  background: #f0f0f0;
  padding: 4px 8px;
  border-radius: 4px;
  margin: 2px;
}
.due-date {
  margin-top: 10px;
  font-size: 0.9em;
  color: #666;
}
.actions {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 10px;
}
.add-btn {
  background: #1976d2;
  color: white;
  border: none;
  padding: 10px 15px;
  border-radius: 5px;
}
.dialog {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
}
.dialog-content {
  background: white;
  padding: 20px;
  border-radius: 8px;
  width: 100%;
  max-width: 500px;
}
.dialog-content input,
.dialog-content textarea,
.dialog-content select {
  width: 100%;
  margin-bottom: 10px;
  padding: 8px;
}
.dialog-actions {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}
</style>
