<template>
  <div class="container">
    <div class="card">
      <div class="card-header">
        <h2>Activity Timeline</h2>
        <div class="filter">
          <label for="filter">Filter by</label>
          <select
            id="filter"
            v-model="selectedFilter"
            @change="fetchActivities"
          >
            <option
              v-for="option in filterOptions"
              :key="option.value"
              :value="option.value"
            >
              {{ option.text }}
            </option>
          </select>
        </div>
      </div>
      <div class="card-body">
        <div class="timeline">
          <div
            v-for="(activity, i) in filteredActivities"
            :key="i"
            :class="['timeline-item', getActivityColor(activity.type)]"
          >
            <div class="opposite">
              <span>{{ formatDate(activity.date) }}</span>
            </div>
            <div class="card">
              <div class="card-title">
                <span :class="getActivityIcon(activity.type)"></span>
                <span>{{ activity.title }}</span>
              </div>
              <div class="card-text">
                <div>{{ activity.description }}</div>
                <div v-if="activity.details" class="details">
                  <span
                    v-for="(detail, key) in activity.details"
                    :key="key"
                    class="chip"
                  >
                    {{ key }}: {{ detail }}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { db, auth } from "../firebase/config";
import { collection, getDocs, query, where } from "firebase/firestore";
import { onAuthStateChanged } from "firebase/auth";

export default {
  name: "UserTimeline",
  data() {
    return {
      activities: [],
      selectedFilter: "all",
      filterOptions: [
        { text: "All Activities", value: "all" },
        { text: "Skills", value: "skills" },
        { text: "Projects", value: "projects" },
        { text: "Objectives", value: "objectives" },
      ],
      currentUser: null,
    };
  },
  computed: {
    filteredActivities() {
      if (this.selectedFilter === "all") {
        return this.activities;
      }
      return this.activities.filter(
        (activity) => activity.type === this.selectedFilter
      );
    },
  },
  created() {
    this.unsubscribe = onAuthStateChanged(auth, (user) => {
      this.currentUser = user;
      if (user) {
        this.fetchActivities();
      } else {
        this.activities = [];
      }
    });
  },
  beforeUnmount() {
    if (this.unsubscribe) {
      this.unsubscribe();
    }
  },
  methods: {
    getActivityColor(type) {
      const colors = {
        skills: "blue",
        projects: "green",
        objectives: "orange",
      };
      return colors[type] || "grey";
    },
    getActivityIcon(type) {
      const icons = {
        skills: "🛠️",
        projects: "📁",
        objectives: "🎯",
      };
      return icons[type] || "ℹ️";
    },
    formatDate(date) {
      return new Date(date).toLocaleDateString();
    },
    async fetchActivities() {
      if (!this.currentUser) return;

      try {
        const activities = [];

        // Fetch skills
        const skillsQuery = query(
          collection(db, "skills"),
          where("userId", "==", this.currentUser.uid)
        );
        const skillsSnapshot = await getDocs(skillsQuery);
        skillsSnapshot.forEach((doc) => {
          const skill = doc.data();
          const skillDate = skill.createdAt?.toDate?.() || new Date();
          activities.push({
            id: doc.id,
            type: "skills",
            title: skill.name,
            description: `Level: ${skill.level}`,
            date: skillDate,
            details: {
              level: skill.level,
              dateAcquired: skillDate.toLocaleDateString(),
            },
          });
        });

        // Fetch projects
        const projectsQuery = query(
          collection(db, "projects"),
          where("userId", "==", this.currentUser.uid)
        );
        const projectsSnapshot = await getDocs(projectsQuery);
        projectsSnapshot.forEach((doc) => {
          const project = doc.data();
          const projectDate = project.createdAt?.toDate?.() || new Date();
          activities.push({
            id: doc.id,
            type: "projects",
            title: project.title,
            description: project.description,
            date: projectDate,
            details: {
              technologies: project.technologies.join(", "),
              githubUrl: project.githubUrl || "No GitHub URL",
            },
          });
        });

        // Fetch objectives
        const objectivesQuery = query(
          collection(db, "objectives"),
          where("userId", "==", this.currentUser.uid)
        );
        const objectivesSnapshot = await getDocs(objectivesQuery);
        objectivesSnapshot.forEach((doc) => {
          const objective = doc.data();
          const objectiveDate = objective.createdAt?.toDate?.() || new Date();
          activities.push({
            id: doc.id,
            type: "objectives",
            title: objective.title,
            description: `Status: ${objective.status}, Progress: ${objective.progress}%`,
            date: objectiveDate,
            details: {
              status: objective.status,
              progress: `${objective.progress}%`,
              dueDate: objective.dueDate,
            },
          });
        });

        // Sort all activities by date
        this.activities = activities.sort((a, b) => b.date - a.date);
      } catch (error) {
        console.error("Error fetching activities:", error);
        this.activities = [];
      }
    },
  },
};
</script>

<style scoped>
.container {
  padding: 2rem;
}

.card {
  border: 1px solid #ddd;
  border-radius: 8px;
  overflow: hidden;
}

.card-header {
  padding: 1rem;
  background-color: #f5f5f5;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.filter select {
  padding: 0.5rem;
  border-radius: 4px;
  border: 1px solid #ccc;
}

.card-body {
  padding: 1rem;
}

.timeline {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.timeline-item {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  padding: 1rem;
  border-left: 4px solid;
}

.timeline-item.blue {
  border-color: blue;
}

.timeline-item.green {
  border-color: green;
}

.timeline-item.orange {
  border-color: orange;
}

.timeline-item .opposite {
  font-size: 0.9rem;
  color: #666;
}

.card {
  background: #fff;
  padding: 1rem;
  border-radius: 8px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

.card-title {
  display: flex;
  align-items: center;
  font-weight: bold;
}

.card-title span {
  margin-left: 10px;
}

.card-text {
  margin-top: 1rem;
}

.chip {
  display: inline-block;
  background-color: #e0e0e0;
  border-radius: 12px;
  padding: 0.5rem;
  margin: 0.25rem 0;
  font-size: 0.9rem;
}

.details {
  margin-top: 0.5rem;
}
</style>
