<template>
  <div class="container">
    <div class="row">
      <div class="col">
        <div class="card card-primary">
          <div class="card-title">
            <span class="icon">{}</span>
            <span class="title">Skills</span>
          </div>
          <div class="card-text">{{ skillsCount }} Skills</div>
          <div class="card-actions">
            <button @click="$router.push('/skills')">View All</button>
          </div>
        </div>
      </div>

      <div class="col">
        <div class="card card-secondary">
          <div class="card-title">
            <span class="icon">{}</span>
            <span class="title">Projects</span>
          </div>
          <div class="card-text">{{ projectsCount }} Projects</div>
          <div class="card-actions">
            <button @click="$router.push('/projects')">View All</button>
          </div>
        </div>
      </div>

      <div class="col">
        <div class="card card-success">
          <div class="card-title">
            <span class="icon">{}</span>
            <span class="title">Objectives</span>
          </div>
          <div class="card-text">{{ objectivesCount }} Objectives</div>
          <div class="card-actions">
            <button @click="$router.push('/objectives')">View All</button>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col">
        <div class="card">
          <div class="card-title">Recent Activity</div>
          <div class="card-text">
            <ul class="timeline">
              <li
                v-for="(activity, i) in recentActivities"
                :key="i"
                :class="'timeline-item ' + activity.color"
              >
                <div class="timeline-content">
                  <strong>{{ activity.title }}</strong>
                  <div>{{ activity.description }}</div>
                  <div class="time">{{ activity.time }}</div>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div class="col">
        <div class="card">
          <div class="card-title">Skills Progress</div>
          <div class="card-text">
            <div
              v-for="(skill, i) in skillsProgress"
              :key="i"
              class="progress-container"
            >
              <div class="progress-label">
                <strong
                  >{{ skill.name }} ({{ Math.ceil(skill.progress) }}%)</strong
                >
              </div>
              <div class="progress-bar-wrapper">
                <div
                  class="progress-bar"
                  :style="{
                    width: skill.progress + '%',
                    backgroundColor: skill.color,
                  }"
                ></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { db, auth } from "../firebase/config";
import { collection, getDocs, query, where } from "firebase/firestore";
import { onAuthStateChanged } from "firebase/auth";

export default {
  name: "UserDashboard",
  data() {
    return {
      skillsCount: 0,
      projectsCount: 0,
      objectivesCount: 0,
      recentActivities: [],
      skillsProgress: [],
      loading: false,
      currentUser: null,
    };
  },
  created() {
    // Listen for auth state changes
    this.unsubscribe = onAuthStateChanged(auth, (user) => {
      this.currentUser = user;
      if (user) {
        console.log("User is authenticated:", user.uid);
        this.fetchCounts();
        this.fetchRecentActivities();
        this.fetchSkillsProgress();
      } else {
        console.log("No user authenticated");
        this.resetData();
      }
    });
  },
  beforeUnmount() {
    if (this.unsubscribe) {
      this.unsubscribe();
    }
  },
  methods: {
    resetData() {
      this.skillsCount = 0;
      this.projectsCount = 0;
      this.objectivesCount = 0;
      this.recentActivities = [];
      this.skillsProgress = [];
    },
    async fetchCounts() {
      if (!this.currentUser) return;

      try {
        this.loading = true;
        console.log("Fetching counts for user:", this.currentUser.uid);

        // Fetch skills count
        const skillsQuery = query(
          collection(db, "skills"),
          where("userId", "==", this.currentUser.uid)
        );
        const skillsSnapshot = await getDocs(skillsQuery);
        this.skillsCount = skillsSnapshot.size;
        console.log("Skills count:", this.skillsCount);

        // Fetch projects count
        const projectsQuery = query(
          collection(db, "projects"),
          where("userId", "==", this.currentUser.uid)
        );
        const projectsSnapshot = await getDocs(projectsQuery);
        this.projectsCount = projectsSnapshot.size;
        console.log("Projects count:", this.projectsCount);

        // Fetch objectives count
        const objectivesQuery = query(
          collection(db, "objectives"),
          where("userId", "==", this.currentUser.uid)
        );
        const objectivesSnapshot = await getDocs(objectivesQuery);
        this.objectivesCount = objectivesSnapshot.size;
        console.log("Objectives count:", this.objectivesCount);
      } catch (error) {
        console.error("Error fetching counts:", error);
        this.resetData();
      } finally {
        this.loading = false;
      }
    },
    async fetchRecentActivities() {
      if (!this.currentUser) return;

      try {
        const activities = [];

        // Fetch recent skills
        const skillsQuery = query(
          collection(db, "skills"),
          where("userId", "==", this.currentUser.uid)
        );
        const skillsSnapshot = await getDocs(skillsQuery);
        skillsSnapshot.forEach((doc) => {
          const skill = doc.data();
          const skillDate =
            skill.createdAt?.toDate?.() ||
            (skill.date instanceof Date ? skill.date : new Date(skill.date)) ||
            new Date();

          activities.push({
            id: doc.id,
            title: `Skill: ${skill.name}`,
            description: `Level: ${skill.level}`,
            time: skillDate.toLocaleString(),
            color: "primary",
            date: skillDate,
            type: "skill",
          });
        });

        // Fetch recent projects
        const projectsQuery = query(
          collection(db, "projects"),
          where("userId", "==", this.currentUser.uid)
        );
        const projectsSnapshot = await getDocs(projectsQuery);
        projectsSnapshot.forEach((doc) => {
          const project = doc.data();
          const projectDate =
            project.createdAt?.toDate?.() ||
            (project.date instanceof Date
              ? project.date
              : new Date(project.date)) ||
            new Date();

          activities.push({
            id: doc.id,
            title: `Project: ${project.title}`,
            description: project.description,
            time: projectDate.toLocaleString(),
            color: "secondary",
            date: projectDate,
            type: "project",
          });
        });

        // Fetch recent objectives
        const objectivesQuery = query(
          collection(db, "objectives"),
          where("userId", "==", this.currentUser.uid)
        );
        const objectivesSnapshot = await getDocs(objectivesQuery);
        objectivesSnapshot.forEach((doc) => {
          const objective = doc.data();
          const objectiveDate =
            objective.createdAt?.toDate?.() ||
            (objective.date instanceof Date
              ? objective.date
              : new Date(objective.date)) ||
            new Date();

          activities.push({
            id: doc.id,
            title: `Objective: ${objective.title}`,
            description: `Status: ${objective.status}, Progress: ${objective.progress}%`,
            time: objectiveDate.toLocaleString(),
            color: "success",
            date: objectiveDate,
            type: "objective",
          });
        });

        // Sort activities by date and take the 5 most recent
        this.recentActivities = activities
          .sort((a, b) => b.date - a.date)
          .slice(0, 5);

        console.log("Recent activities updated:", this.recentActivities);
      } catch (error) {
        console.error("Error fetching activities:", error);
        this.recentActivities = [
          {
            title: "Error loading activities",
            description: "Please try refreshing the page",
            time: "Just now",
            color: "error",
          },
        ];
      }
    },
    async fetchSkillsProgress() {
      if (!this.currentUser) return;

      try {
        const skillsQuery = query(
          collection(db, "skills"),
          where("userId", "==", this.currentUser.uid)
        );
        const skillsSnapshot = await getDocs(skillsQuery);

        if (skillsSnapshot.empty) {
          this.skillsProgress = [
            {
              name: "No skills added yet",
              progress: 0,
              color: "grey",
              level: 0,
            },
          ];
          return;
        }

        this.skillsProgress = skillsSnapshot.docs
          .map((doc) => {
            const skill = doc.data();
            const level = parseInt(skill.level) || 0;
            const progress = Math.min(Math.max(level * 20, 0), 100); // Ensure progress is between 0-100

            return {
              name: skill.name,
              progress: progress,
              color: this.getProgressColor(level),
              level: level,
            };
          })
          .sort((a, b) => b.progress - a.progress); // Sort by progress descending

        console.log("Skills progress updated:", this.skillsProgress);
      } catch (error) {
        console.error("Error fetching skills progress:", error);
        this.skillsProgress = [
          {
            name: "Error loading skills",
            progress: 0,
            color: "error",
            level: 0,
          },
        ];
      }
    },
    getProgressColor(level) {
      const colors = {
        0: "grey",
        1: "error",
        2: "warning",
        3: "info",
        4: "success",
        5: "primary",
      };
      return colors[level] || "grey";
    },
  },
};
</script>

<style scoped>
.container {
  padding: 20px;
}
.row {
  display: flex;
  flex-wrap: wrap;
  margin-bottom: 20px;
}
.col {
  flex: 1;
  min-width: 300px;
  margin: 10px;
}
.card {
  border: 1px solid #ccc;
  border-radius: 8px;
  padding: 16px;
  box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
}
.card-primary {
  background-color: #1976d2;
  color: white;
}
.card-secondary {
  background-color: #9c27b0;
  color: white;
}
.card-success {
  background-color: #4caf50;
  color: white;
}
.card-title {
  font-size: 1.2em;
  margin-bottom: 8px;
  display: flex;
  align-items: center;
}
.card-text {
  font-size: 1em;
  margin: 10px 0;
}
.card-actions button {
  background: none;
  border: none;
  color: inherit;
  text-decoration: underline;
  cursor: pointer;
  padding: 0;
}
.timeline {
  list-style: none;
  padding: 0;
}
.timeline-item {
  margin-bottom: 15px;
  padding-left: 10px;
  border-left: 3px solid #ccc;
}
.timeline-item.primary {
  border-color: #1976d2;
}
.timeline-item.secondary {
  border-color: #9c27b0;
}
.timeline-item.success {
  border-color: #4caf50;
}
.timeline-item.error {
  border-color: red;
}
.timeline-content {
  margin-left: 10px;
}
.time {
  font-size: 0.8em;
  color: gray;
}
.progress-container {
  margin-bottom: 15px;
}
.progress-label {
  margin-bottom: 5px;
}
.progress-bar-wrapper {
  width: 100%;
  background-color: #eee;
  border-radius: 5px;
  overflow: hidden;
}
.progress-bar {
  height: 25px;
  transition: width 0.3s ease-in-out;
}
</style>
