<template>
  <div id="app">
    <header class="app-bar">
      <button
        class="menu-icon"
        @click="drawer = !drawer"
        v-if="isAuthenticated"
      >
        ☰
      </button>
      <h1 class="title">DevGate</h1>
      <button class="logout-btn" @click="logout" v-if="isAuthenticated">
        Logout
      </button>
    </header>

    <div v-if="isAuthenticated">
      <nav class="sidebar" :class="{ 'is-open': drawer }">
        <ul>
          <li v-for="item in menuItems" :key="item.title">
            <router-link :to="item.path">
              <span :class="item.icon"></span> {{ item.title }}
            </router-link>
          </li>
        </ul>
      </nav>
    </div>

    <main :class="{ authenticated: isAuthenticated }">
      <router-view></router-view>
    </main>
  </div>
</template>

<script>
import { auth } from "./firebase/config";

export default {
  name: "App",
  data() {
    return {
      drawer: true,
      isAuthenticated: false,
      menuItems: [
        { title: "Dashboard", path: "/dashboard", icon: "mdi-view-dashboard" },
        { title: "Skills", path: "/skills", icon: "mdi-code-braces" },
        { title: "Projects", path: "/projects", icon: "mdi-folder" },
        { title: "Timeline", path: "/timeline", icon: "mdi-timeline" },
        { title: "Objectives", path: "/objectives", icon: "mdi-target" },
      ],
    };
  },
  created() {
    this.checkAuth();
    auth.onAuthStateChanged((user) => {
      this.isAuthenticated = !!user;
    });
  },
  methods: {
    checkAuth() {
      this.isAuthenticated = !!localStorage.getItem("user");
    },
    async logout() {
      try {
        await auth.signOut();
        localStorage.removeItem("user");
        this.$router.push("/"); // Redirect to login page
      } catch (error) {
        console.error("Error logging out:", error);
      }
    },
  },
};
</script>
<style scoped>
/* Basic reset and structure */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: Arial, sans-serif;
}

/* Sidebar */
.sidebar {
  position: fixed;
  top: 60px; /* Below header */
  left: 0;
  width: 250px;
  height: calc(100vh - 60px);
  background-color: #2c3e50;
  color: white;
  padding: 20px 0;
  transform: translateX(-100%);
  transition: transform 0.3s ease;
  z-index: 90;
}

.sidebar.is-open {
  transform: translateX(0);
}

.sidebar ul {
  list-style: none;
  padding: 0;
}

.sidebar li {
  margin: 15px 0;
}

.sidebar a {
  color: white;
  text-decoration: none;
  font-size: 16px;
  display: flex;
  align-items: center;
  padding: 10px 20px;
  transition: all 0.2s;
}

.sidebar a span {
  margin-right: 10px;
}

.sidebar a:hover {
  background-color: #34495e;
  padding-left: 25px;
}

/* Header */
.app-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #2c3e50;
  color: white;
  padding: 15px 20px;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  height: 60px;
  z-index: 100;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.menu-icon {
  background: none;
  border: none;
  color: white;
  font-size: 24px;
  cursor: pointer;
  padding: 5px;
}

.title {
  font-size: 22px;
  font-weight: 600;
}

.logout-btn {
  background: none;
  border: none;
  color: white;
  font-size: 16px;
  cursor: pointer;
  padding: 8px 15px;
  border-radius: 4px;
  transition: background-color 0.2s;
}

.logout-btn:hover {
  background-color: rgba(255, 255, 255, 0.1);
}

/* Main content */
main {
  padding-top: 80px;
  padding-left: 20px;
  padding-right: 20px;
  min-height: calc(100vh - 60px);
  transition: margin-left 0.3s;
}

main.authenticated {
  margin-left: 250px;
}

@media screen and (max-width: 768px) {
  main.authenticated {
    margin-left: 0;
  }

  .sidebar {
    width: 80%;
  }

  .app-bar {
    padding: 15px;
  }
}
</style>
