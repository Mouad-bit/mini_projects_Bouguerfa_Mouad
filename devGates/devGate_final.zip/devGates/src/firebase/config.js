import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyAFrXUWwz2EyGhz6Fiw_ZffKqqn17ND64Y",
  authDomain: "devgate-47c15.firebaseapp.com",
  projectId: "devgate-47c15",
  storageBucket: "devgate-47c15.firebasestorage.app",
  messagingSenderId: "827701037886",
  appId: "1:827701037886:web:03032effa93b97bf907a6f",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize services
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);

export { auth, db, storage };
