const { defineConfig } = require("@vue/cli-service");

module.exports = defineConfig({
  transpileDependencies: true,
  configureWebpack: {
    resolve: {
      alias: {
        "vuetify/lib": "vuetify",
        "vuetify/components": "vuetify/lib/components",
        "vuetify/directives": "vuetify/lib/directives",
        "vuetify/styles": "vuetify/lib/styles",
      },
    },
  },
  css: {
    loaderOptions: {
      sass: {
        implementation: require("sass"),
      },
    },
  },
});
