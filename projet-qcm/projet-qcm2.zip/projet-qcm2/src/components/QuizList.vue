<template>
  <div class="quiz-list">
    <div v-for="quiz in quizzes" :key="quiz.id" class="quiz-item">
      <div class="quiz-info">
        <h3>{{ quiz.title }}</h3>
        <p>{{ quiz.description }}</p>
        <div class="quiz-meta">
          <span>Category: {{ quiz.category }}</span>
          <span>Difficulty: {{ quiz.difficulty }}</span>
          <span>Questions: {{ quiz.questions.length }}</span>
        </div>
      </div>
      <router-link :to="'/quiz/' + quiz.id" class="btn-primary">
        Start Quiz
      </router-link>
    </div>
  </div>
</template>

<script>
import { mapState } from "vuex";

export default {
  name: "QuizList",
  computed: {
    ...mapState(["quizzes"]),
  },
};
</script>

<style>
.quiz-list {
  display: grid;
  gap: 1.5rem;
}

.quiz-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: white;
  padding: 1.5rem;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.quiz-info {
  flex: 1;
}

.quiz-info h3 {
  margin: 0 0 0.5rem;
  color: var(--primary-color);
}

.quiz-info p {
  margin: 0 0 1rem;
  color: #666;
}

.quiz-meta {
  display: flex;
  gap: 1rem;
  color: #888;
  font-size: 0.9rem;
}

.btn-primary {
  padding: 0.75rem 1.5rem;
  background-color: var(--primary-color);
  color: white;
  text-decoration: none;
  border-radius: 4px;
  transition: background-color 0.3s ease;
}

.btn-primary:hover {
  background-color: var(--primary-color-dark);
}

@media (max-width: 768px) {
  .quiz-item {
    flex-direction: column;
    gap: 1rem;
  }

  .quiz-meta {
    flex-direction: column;
    gap: 0.5rem;
  }

  .btn-primary {
    width: 100%;
    text-align: center;
  }
}
</style>
