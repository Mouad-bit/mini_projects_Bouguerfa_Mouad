<template>
  <div class="quiz-container">
    <div v-if="!quizCompleted" class="quiz-content">
      <h2>{{ currentQuiz.title }}</h2>
      <p>{{ currentQuiz.description }}</p>
      <div class="progress-bar">
        <div
          class="progress"
          :style="{
            width: ((currentQuestionIndex + 1) / totalQuestions) * 100 + '%',
          }"
        ></div>
      </div>
      <div class="question-container">
        <h3>Question {{ currentQuestionIndex + 1 }} of {{ totalQuestions }}</h3>
        <p class="question-text">{{ currentQuestion.text }}</p>
        <div class="options-container">
          <div
            v-for="(option, index) in currentQuestion.options"
            :key="index"
            class="option"
            :class="{ selected: answers[currentQuestionIndex] === index }"
            @click="selectAnswer(index)"
          >
            {{ option }}
          </div>
        </div>
      </div>
      <div class="navigation-buttons">
        <button
          v-if="currentQuestionIndex > 0"
          @click="previousQuestion"
          class="btn-secondary"
        >
          Previous
        </button>
        <button
          v-if="currentQuestionIndex < totalQuestions - 1"
          @click="nextQuestion"
          class="btn-primary"
          :disabled="answers[currentQuestionIndex] === undefined"
        >
          Next
        </button>
        <button
          v-else
          @click="finishQuiz"
          class="btn-primary"
          :disabled="answers[currentQuestionIndex] === undefined"
        >
          Finish Quiz
        </button>
      </div>
    </div>

    <div v-else class="results-container">
      <h2>Quiz Results</h2>
      <div class="score-summary">
        <h3>Your Score: {{ score }}/{{ totalQuestions }}</h3>
        <p>Percentage: {{ ((score / totalQuestions) * 100).toFixed(1) }}%</p>
      </div>

      <div class="detailed-results">
        <h3>Detailed Results</h3>
        <div
          v-for="(question, index) in currentQuiz.questions"
          :key="index"
          class="result-item"
          :class="{
            correct:
              question.options[answers[index]] === question.correctAnswer,
            incorrect:
              question.options[answers[index]] !== question.correctAnswer,
          }"
        >
          <div class="question-result">
            <h4>Question {{ index + 1 }}</h4>
            <p>{{ question.text }}</p>
            <div class="answer-details">
              <p>
                Your answer:
                <span
                  :class="{
                    'correct-answer':
                      question.options[answers[index]] ===
                      question.correctAnswer,
                    'incorrect-answer':
                      question.options[answers[index]] !==
                      question.correctAnswer,
                  }"
                >
                  {{ question.options[answers[index]] }}
                </span>
              </p>
              <p
                v-if="
                  question.options[answers[index]] !== question.correctAnswer
                "
              >
                Correct answer:
                <span class="correct-answer">
                  {{ question.correctAnswer }}
                </span>
              </p>
            </div>
          </div>
        </div>
      </div>

      <div class="result-actions">
        <button @click="retakeQuiz" class="btn-primary">Retake Quiz</button>
        <router-link to="/quizzes" class="btn-secondary"
          >Back to Quizzes</router-link
        >
      </div>
    </div>
  </div>
</template>

<script>
import { ref, computed, onMounted } from "vue";
import { useRoute, useRouter } from "vue-router";
import { useStore } from "vuex";
import { collection, addDoc } from "firebase/firestore";
import { db } from "../firebase/config";

export default {
  name: "QuizComponent",
  setup() {
    const store = useStore();
    const route = useRoute();
    const router = useRouter();

    const currentQuestionIndex = ref(0);
    const answers = ref([]);
    const quizCompleted = ref(false);
    const score = ref(0);

    const currentQuiz = computed(() => {
      return store.state.quizzes.quizzes.find(
        (quiz) => quiz.id === route.params.id
      );
    });

    const totalQuestions = computed(() => currentQuiz.value.questions.length);
    const currentQuestion = computed(
      () => currentQuiz.value.questions[currentQuestionIndex.value]
    );

    onMounted(async () => {
      await store.dispatch("quizzes/fetchQuizzes");
      if (!currentQuiz.value) {
        router.push("/quizzes");
      } else {
        answers.value = new Array(currentQuiz.value.questions.length).fill(
          undefined
        );
      }
    });

    const selectAnswer = (index) => {
      answers.value[currentQuestionIndex.value] = index;
    };

    const calculateScore = () => {
      score.value = 0;
      for (let i = 0; i < answers.value.length; i++) {
        const userAnswer = answers.value[i];
        const correctAnswer = currentQuiz.value.questions[i].correctAnswer;

        if (
          currentQuiz.value.questions[i].options[userAnswer] == correctAnswer
        ) {
          score.value++;
        }
      }
    };

    const saveQuizResult = async () => {
      try {
        const user = store.state.user.user;
        if (!user) return;

        if (answers.value.some((answer) => answer === undefined)) {
          console.error("Some answers are missing");
          return;
        }

        const result = {
          userId: user.uid,
          quizId: currentQuiz.value.id,
          score: score.value,
          totalQuestions: totalQuestions.value,
          answers: answers.value,
          timestamp: new Date(),
        };

        await addDoc(collection(db, "quizResults"), result);
      } catch (error) {
        console.error("Error saving quiz result:", error);
      }
    };

    const nextQuestion = () => {
      if (currentQuestionIndex.value < totalQuestions.value - 1) {
        currentQuestionIndex.value++;
      }
    };

    const previousQuestion = () => {
      if (currentQuestionIndex.value > 0) {
        currentQuestionIndex.value--;
      }
    };

    const finishQuiz = () => {
      calculateScore();
      saveQuizResult();
      quizCompleted.value = true;
    };

    const retakeQuiz = () => {
      currentQuestionIndex.value = 0;
      answers.value = new Array(currentQuiz.value.questions.length).fill(
        undefined
      );
      quizCompleted.value = false;
      score.value = 0;
    };

    return {
      currentQuiz,
      currentQuestionIndex,
      answers,
      quizCompleted,
      score,
      totalQuestions,
      currentQuestion,
      selectAnswer,
      nextQuestion,
      previousQuestion,
      finishQuiz,
      retakeQuiz,
    };
  },
};
</script>

<style scoped>
.quiz-container {
  max-width: 800px;
  margin: 0 auto;
  padding: 2rem;
}

.quiz-content {
  background: white;
  padding: 2rem;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.progress-bar {
  height: 10px;
  background-color: #f0f0f0;
  border-radius: 5px;
  margin: 1rem 0;
  overflow: hidden;
}

.progress {
  height: 100%;
  background-color: var(--primary-color);
  transition: width 0.3s ease;
}

.question-container {
  margin: 2rem 0;
}

.question-text {
  font-size: 1.2rem;
  margin: 1rem 0;
}

.options-container {
  display: grid;
  gap: 1rem;
  margin-top: 1.5rem;
}

.option {
  padding: 1rem;
  border: 1px solid #ddd;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.option:hover {
  background-color: #f8f9fa;
}

.option.selected {
  background-color: var(--primary-color);
  color: white;
  border-color: var(--primary-color);
}

.navigation-buttons {
  display: flex;
  justify-content: space-between;
  margin-top: 2rem;
}

.results-container {
  background: white;
  padding: 2rem;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.score-summary {
  text-align: center;
  margin-bottom: 2rem;
}

.score-summary h3 {
  color: var(--primary-color);
  font-size: 1.5rem;
}

.detailed-results {
  margin: 2rem 0;
}

.result-item {
  padding: 1rem;
  margin-bottom: 1rem;
  border-radius: 4px;
}

.result-item.correct {
  background-color: #d4edda;
  border: 1px solid #c3e6cb;
}

.result-item.incorrect {
  background-color: #f8d7da;
  border: 1px solid #f5c6cb;
}

.question-result h4 {
  margin-top: 0;
  color: #333;
}

.answer-details {
  margin-top: 0.5rem;
}

.correct-answer {
  color: #28a745;
  font-weight: bold;
}

.incorrect-answer {
  color: #dc3545;
  font-weight: bold;
}

.result-actions {
  display: flex;
  gap: 1rem;
  justify-content: center;
  margin-top: 2rem;
}

.btn-primary,
.btn-secondary {
  padding: 0.75rem 1.5rem;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-primary {
  background-color: var(--primary-color);
  color: white;
}

.btn-secondary {
  background-color: #6c757d;
  color: white;
}

.btn-primary:hover,
.btn-secondary:hover {
  opacity: 0.9;
}

.btn-primary:disabled,
.btn-secondary:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
</style>
