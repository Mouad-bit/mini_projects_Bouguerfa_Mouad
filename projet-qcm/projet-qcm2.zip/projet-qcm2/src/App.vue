<template>
  <div id="app">
    <nav class="navbar">
      <div class="container">
        <div class="nav-header">
          <div class="nav-brand">Welcome to Quiz App</div>
          <button
            class="menu-toggle"
            @click="toggleMenu"
            :class="{ 'is-active': isMenuOpen }"
          >
            <span class="menu-icon"></span>
          </button>
        </div>
        <div class="nav-links" :class="{ 'show-menu': isMenuOpen }">
          <template v-if="isAuthenticated">
            <router-link to="/" class="nav-link" @click="closeMenu"
              >Home</router-link
            >
            <router-link to="/quizzes" class="nav-link" @click="closeMenu"
              >Quizzes</router-link
            >
            <router-link to="/leaderboard" class="nav-link" @click="closeMenu"
              >Leaderboard</router-link
            >
            <router-link
              v-if="isAdmin"
              to="/admin"
              class="nav-link"
              @click="closeMenu"
              >Admin Dashboard</router-link
            >
          </template>
          <div class="auth-buttons">
            <template v-if="isAuthenticated">
              <router-link to="/profile" class="auth-button" @click="closeMenu"
                >Profile</router-link
              >
              <button class="auth-button" @click="handleLogout">Logout</button>
            </template>
            <template v-else>
              <router-link to="/login" class="auth-button" @click="closeMenu"
                >Login</router-link
              >
              <router-link to="/register" class="auth-button" @click="closeMenu"
                >Register</router-link
              >
            </template>
          </div>
        </div>
      </div>
    </nav>

    <div class="container mt-4">
      <router-view></router-view>
    </div>
  </div>
</template>

<script>
import { ref, computed } from "vue";
import { useStore } from "vuex";
import { useRouter } from "vue-router";
import { getAuth, signOut } from "firebase/auth";

export default {
  name: "App",
  setup() {
    const store = useStore();
    const router = useRouter();
    const isMenuOpen = ref(false);

    // Initialize auth state
    store.dispatch("user/initAuth");

    const isAuthenticated = computed(
      () => store.getters["user/isAuthenticated"]
    );
    const isAdmin = computed(() => {
      const user = store.state.user?.user;
      return user?.role === "admin";
    });

    const handleLogout = async () => {
      try {
        const auth = getAuth();
        await signOut(auth);
        router.push("/login");
      } catch (error) {
        console.error("Logout error:", error);
      }
    };

    const toggleMenu = () => {
      isMenuOpen.value = !isMenuOpen.value;
    };

    const closeMenu = () => {
      isMenuOpen.value = false;
    };

    return {
      isAuthenticated,
      isAdmin,
      handleLogout,
      isMenuOpen,
      toggleMenu,
      closeMenu,
    };
  },
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
}

.navbar {
  background-color: var(--primary-color);
  padding: 1rem 0;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 1rem;
}

.nav-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.nav-brand {
  color: white;
  font-size: 1.5rem;
  font-weight: bold;
  text-decoration: none;
}

.menu-toggle {
  display: none;
  background: none;
  border: none;
  cursor: pointer;
  padding: 0.5rem;
  position: relative;
  z-index: 1000;
}

.menu-icon {
  display: block;
  width: 25px;
  height: 3px;
  background-color: white;
  position: relative;
  transition: background-color 0.3s ease;
}

.menu-icon::before,
.menu-icon::after {
  content: "";
  position: absolute;
  width: 25px;
  height: 3px;
  background-color: white;
  transition: transform 0.3s ease;
}

.menu-icon::before {
  top: -8px;
}

.menu-icon::after {
  bottom: -8px;
}

.menu-toggle.is-active .menu-icon {
  background-color: transparent;
}

.menu-toggle.is-active .menu-icon::before {
  transform: translateY(8px) rotate(45deg);
}

.menu-toggle.is-active .menu-icon::after {
  transform: translateY(-8px) rotate(-45deg);
}

.nav-links {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 1rem;
}

.nav-link {
  color: white;
  text-decoration: none;
  padding: 0.5rem 1rem;
  margin: 0 0.5rem;
  border-radius: 4px;
  transition: background-color 0.3s ease;
}

.nav-link:hover {
  background-color: rgba(255, 255, 255, 0.1);
}

.auth-buttons {
  display: flex;
  gap: 0.5rem;
}

.auth-button {
  color: white;
  text-decoration: none;
  padding: 0.5rem 1rem;
  border: 1px solid white;
  border-radius: 4px;
  background: none;
  cursor: pointer;
  transition: all 0.3s ease;
}

.auth-button:hover {
  background-color: white;
  color: var(--primary-color);
}

@media (max-width: 768px) {
  .menu-toggle {
    display: block;
  }

  .nav-links {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: var(--primary-color);
    padding: 2rem;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
    margin-top: 0;
    transform: translateX(-100%);
    transition: transform 0.3s ease;
    z-index: 1000;
  }

  .nav-links.show-menu {
    display: flex;
    transform: translateX(0);
  }

  .nav-links.show-menu::before {
    content: "";
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(0, 0, 0, 0.5);
    z-index: -1;
  }

  .nav-link {
    margin: 1rem 0;
    width: 100%;
    text-align: left;
    font-size: 1.2rem;
    z-index: 1001;
  }

  .auth-buttons {
    flex-direction: column;
    width: 100%;
    margin-top: 2rem;
    z-index: 1001;
  }

  .auth-button {
    width: 100%;
    text-align: left;
    margin: 0.5rem 0;
  }

  /* Hide content when menu is open */
  .container.mt-4 {
    transition: opacity 0.3s ease;
  }

  .nav-links.show-menu ~ .container.mt-4 {
    opacity: 0;
    pointer-events: none;
  }
}
</style>
