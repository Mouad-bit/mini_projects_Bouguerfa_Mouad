import { createRouter, createWebHistory } from "vue-router";
import { auth } from "../firebase/config";

const routes = [
  {
    path: "/",
    name: "Home",
    component: () => import("../views/Home.vue"),
  },
  {
    path: "/login",
    name: "Login",
    component: () => import("../views/Login.vue"),
  },
  {
    path: "/register",
    name: "Register",
    component: () => import("../components/Register.vue"),
  },
  {
    path: "/quizzes",
    name: "Quizzes",
    component: () => import("../views/Quizzes.vue"),
    meta: { requiresAuth: true },
  },
  {
    path: "/quiz/:id",
    name: "Quiz",
    component: () => import("../components/QuizComponent.vue"),
    meta: { requiresAuth: true },
  },
  {
    path: "/leaderboard",
    name: "Leaderboard",
    component: () => import("../views/Leaderboard.vue"),
    meta: { requiresAuth: true },
  },
  {
    path: "/profile",
    name: "Profile",
    component: () => import("../views/Profile.vue"),
    meta: { requiresAuth: true },
  },
  {
    path: "/admin",
    name: "Admin",
    component: () => import("../views/Admin.vue"),
    meta: { requiresAuth: true, requiresAdmin: true },
  },
];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
});

router.beforeEach(async (to, from, next) => {
  const requiresAuth = to.matched.some((record) => record.meta.requiresAuth);
  const requiresAdmin = to.matched.some((record) => record.meta.requiresAdmin);
  const isAuthenticated = auth.currentUser;
  const userRole = isAuthenticated
    ? (await auth.currentUser.getIdTokenResult()).claims.role
    : null;

  if (requiresAuth && !isAuthenticated) {
    next("/login");
  } else if (requiresAdmin && userRole !== "admin") {
    next("/");
  } else {
    next();
  }
});

export default router;
