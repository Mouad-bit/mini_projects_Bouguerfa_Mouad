import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyC9T5mgPYEnQclaDzqVKgmky8S0pS1F4R0",
  authDomain: "project-qcm.firebaseapp.com",
  projectId: "project-qcm",
  storageBucket: "project-qcm.firebasestorage.app",
  messagingSenderId: "368213712940",
  appId: "1:368213712940:web:8c657aac1152c27cdf3189",
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

export { db, auth };
