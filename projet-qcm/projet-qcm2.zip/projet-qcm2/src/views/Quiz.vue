<template>
  <div class="quiz-view">
    <div v-if="loading" class="loading">Loading quiz...</div>
    <div v-else-if="quizCompleted" class="quiz-completed">
      <div class="quiz-card">
        <h2>Quiz Completed!</h2>
        <p>Your score: {{ ((score / totalQuestions) * 100).toFixed(1) }}%</p>
        <div class="button-group">
          <button @click="restartQuiz" class="btn-primary">Try Again</button>
          <router-link to="/quizzes" class="btn-secondary"
            >Back to Quizzes</router-link
          >
        </div>
      </div>
    </div>
    <div v-else class="quiz-container">
      <div class="quiz-header">
        <h2>{{ currentQuiz.title }}</h2>
        <p>Question {{ currentQuestionIndex + 1 }} of {{ totalQuestions }}</p>
      </div>
      <div class="quiz-body">
        <h3>{{ currentQuestion.question }}</h3>
        <div class="options">
          <button
            v-for="(option, index) in currentQuestion.options"
            :key="index"
            class="option-button"
            :class="{ selected: selectedAnswer === index }"
            @click="selectAnswer(index)"
          >
            {{ option }}
          </button>
        </div>
      </div>
      <div class="quiz-footer">
        <button
          @click="nextQuestion"
          class="btn-primary"
          :disabled="selectedAnswer === null"
        >
          {{ isLastQuestion ? "Finish Quiz" : "Next Question" }}
        </button>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, computed, onMounted } from "vue";
import { useRoute, useRouter } from "vue-router";
import { useStore } from "vuex";
import { doc, getDoc, collection, addDoc } from "firebase/firestore";
import { db } from "../firebase/config";

export default {
  name: "QuizPage",
  setup() {
    const route = useRoute();
    const router = useRouter();
    const store = useStore();

    const loading = ref(true);
    const currentQuestionIndex = ref(0);
    const selectedAnswer = ref(null);
    const showFeedback = ref(false);
    const score = ref(0);
    const quizCompleted = ref(false);

    const currentQuiz = computed(() => store.state.currentQuiz);
    const currentQuestion = computed(
      () => currentQuiz.value?.questions[currentQuestionIndex.value]
    );
    const totalQuestions = computed(
      () => currentQuiz.value?.questions.length || 0
    );
    const isLastQuestion = computed(
      () => currentQuestionIndex.value === totalQuestions.value - 1
    );
    const isCorrect = computed(() => {
      if (!showFeedback.value) return false;
      return (
        currentQuestion.value.options[selectedAnswer.value] ===
        currentQuestion.value.correctAnswer
      );
    });

    const loadQuiz = async () => {
      try {
        loading.value = true;
        const quizDoc = await getDoc(doc(db, "quizzes", route.params.id));
        if (quizDoc.exists()) {
          store.commit("setCurrentQuiz", { id: quizDoc.id, ...quizDoc.data() });
        } else {
          router.push("/quizzes");
        }
      } catch (error) {
        console.error("Error loading quiz:", error);
        router.push("/quizzes");
      } finally {
        loading.value = false;
      }
    };

    const selectAnswer = (index) => {
      if (showFeedback.value) return;
      selectedAnswer.value = index;
      showFeedback.value = true;

      if (
        currentQuestion.value.options[index] ===
        currentQuestion.value.correctAnswer
      ) {
        score.value++;
      }
    };

    const nextQuestion = () => {
      if (isLastQuestion.value) {
        saveQuizResult();
        quizCompleted.value = true;
      } else {
        currentQuestionIndex.value++;
        selectedAnswer.value = null;
        showFeedback.value = false;
      }
    };

    const saveQuizResult = async () => {
      try {
        await addDoc(collection(db, "quizResults"), {
          userId: store.state.user.uid,
          quizId: currentQuiz.value.id,
          score: score.value,
          totalQuestions: totalQuestions.value,
          timestamp: new Date(),
        });
      } catch (error) {
        console.error("Error saving quiz result:", error);
      }
    };

    const restartQuiz = () => {
      currentQuestionIndex.value = 0;
      selectedAnswer.value = null;
      showFeedback.value = false;
      score.value = 0;
      quizCompleted.value = false;
    };

    onMounted(loadQuiz);

    return {
      loading,
      currentQuiz,
      currentQuestion,
      currentQuestionIndex,
      selectedAnswer,
      showFeedback,
      score,
      totalQuestions,
      quizCompleted,
      isLastQuestion,
      isCorrect,
      selectAnswer,
      nextQuestion,
      restartQuiz,
    };
  },
};
</script>

<style>
.quiz-view {
  max-width: 800px;
  margin: 0 auto;
  padding: 2rem;
}

.loading {
  text-align: center;
  font-size: 1.2rem;
  color: #666;
}

.quiz-completed {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 50vh;
}

.quiz-card {
  background: white;
  padding: 2rem;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  text-align: center;
}

.quiz-card h2 {
  color: var(--primary-color);
  margin-bottom: 1rem;
}

.quiz-card p {
  font-size: 1.2rem;
  margin-bottom: 2rem;
}

.button-group {
  display: flex;
  gap: 1rem;
  justify-content: center;
}

.quiz-container {
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  overflow: hidden;
}

.quiz-header {
  padding: 1.5rem;
  background-color: var(--primary-color);
  color: white;
}

.quiz-header h2 {
  margin: 0;
  font-size: 1.5rem;
}

.quiz-header p {
  margin: 0.5rem 0 0;
  opacity: 0.9;
}

.quiz-body {
  padding: 2rem;
}

.quiz-body h3 {
  margin-bottom: 2rem;
  color: #333;
}

.options {
  display: grid;
  gap: 1rem;
}

.option-button {
  padding: 1rem;
  border: 2px solid #ddd;
  border-radius: 4px;
  background: white;
  text-align: left;
  cursor: pointer;
  transition: all 0.3s ease;
}

.option-button:hover {
  border-color: var(--primary-color);
  background-color: rgba(var(--primary-color-rgb), 0.05);
}

.option-button.selected {
  border-color: var(--primary-color);
  background-color: rgba(var(--primary-color-rgb), 0.1);
}

.quiz-footer {
  padding: 1.5rem;
  border-top: 1px solid #eee;
  text-align: right;
}

.btn-primary {
  padding: 0.75rem 1.5rem;
  background-color: var(--primary-color);
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.btn-primary:hover:not(:disabled) {
  background-color: var(--primary-color-dark);
}

.btn-primary:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.btn-secondary {
  padding: 0.75rem 1.5rem;
  background-color: white;
  color: var(--primary-color);
  border: 1px solid var(--primary-color);
  border-radius: 4px;
  text-decoration: none;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-secondary:hover {
  background-color: rgba(var(--primary-color-rgb), 0.05);
}
</style>
