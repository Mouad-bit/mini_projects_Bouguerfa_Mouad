<template>
  <div class="quizzes">
    <h2>Available Quizzes</h2>
    <div v-if="loading" class="loading">Loading quizzes...</div>
    <div v-else-if="error" class="error">{{ error }}</div>
    <div v-else-if="filteredQuizzes.length === 0" class="no-quizzes">
      No quizzes available at the moment.
    </div>
    <div v-else class="quiz-list">
      <div v-for="quiz in filteredQuizzes" :key="quiz.id" class="quiz-card">
        <h3>{{ quiz.title }}</h3>
        <p>{{ quiz.description }}</p>
        <button @click="startQuiz(quiz)" class="start-btn">Start Quiz</button>
      </div>
    </div>
  </div>
</template>

<script>
import { computed, ref, onMounted } from "vue";
import { useStore } from "vuex";
import { useRouter } from "vue-router";

export default {
  name: "QuizzesView",
  setup() {
    const store = useStore();
    const router = useRouter();
    const loading = ref(true);
    const error = ref(null);

    const filteredQuizzes = computed(() => {
      const quizzes = store.state.quizzes?.quizzes || [];
      return quizzes.filter((quiz) => quiz.isActive);
    });

    const startQuiz = (quiz) => {
      router.push(`/quiz/${quiz.id}`);
    };

    onMounted(async () => {
      try {
        await store.dispatch("quizzes/fetchQuizzes");
      } catch (err) {
        error.value = "Failed to load quizzes. Please try again later.";
        console.error("Error loading quizzes:", err);
      } finally {
        loading.value = false;
      }
    });

    return {
      filteredQuizzes,
      loading,
      error,
      startQuiz,
    };
  },
};
</script>

<style scoped>
.quizzes {
  padding: 20px;
}

.loading,
.error,
.no-quizzes {
  text-align: center;
  padding: 20px;
  font-size: 1.2em;
}

.error {
  color: red;
}

.quiz-list {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 20px;
  padding: 20px 0;
}

.quiz-card {
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 20px;
  background: white;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.quiz-card h3 {
  margin: 0 0 10px 0;
  color: #2c3e50;
}

.quiz-card p {
  margin: 0 0 15px 0;
  color: #666;
}

.start-btn {
  background-color: #4caf50;
  color: white;
  border: none;
  padding: 8px 16px;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s;
}

.start-btn:hover {
  background-color: #45a049;
}
</style>
