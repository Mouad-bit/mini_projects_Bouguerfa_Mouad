<template>
  <div class="home-container">
    <div class="welcome-section">
      <h1>Welcome to Quiz App</h1>
      <p>Test your knowledge with our interactive quizzes!</p>
      <router-link to="/quizzes" class="btn-primary"
        >Browse Quizzes</router-link
      >
    </div>
  </div>
</template>

<script>
import { mapState } from "vuex";

export default {
  name: "HomeView",
  computed: {
    ...mapState(["isAuthenticated"]),
  },
};
</script>

<style>
.home-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 80vh;
  text-align: center;
  padding: 2rem;
}

.welcome-section {
  max-width: 600px;
}

.welcome-section h1 {
  font-size: 2.5rem;
  color: var(--primary-color);
  margin-bottom: 1rem;
}

.welcome-section p {
  font-size: 1.2rem;
  color: #666;
  margin-bottom: 2rem;
}

.btn-primary {
  display: inline-block;
  padding: 0.75rem 1.5rem;
  background-color: var(--primary-color);
  color: white;
  text-decoration: none;
  border-radius: 4px;
  font-size: 1.1rem;
  transition: background-color 0.3s ease;
}

.btn-primary:hover {
  background-color: var(--primary-color-dark);
  color: black;
}
</style>
