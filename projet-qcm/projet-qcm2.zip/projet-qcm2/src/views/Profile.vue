<template>
  <div class="profile-container">
    <div class="profile-header">
      <h1>Profile</h1>
    </div>

    <div class="profile-content">
      <div class="user-info">
        <h2>User Information</h2>
        <div class="info-item">
          <span class="label">Email:</span>
          <span class="value">{{ user?.email }}</span>
        </div>
        <div class="info-item">
          <span class="label">Role:</span>
          <span class="value">{{ user?.role }}</span>
        </div>
      </div>

      <div class="quiz-history">
        <h2>Quiz History</h2>
        <div v-if="quizHistory.length > 0" class="history-list">
          <div
            v-for="result in quizHistory"
            :key="result.id"
            class="history-item"
          >
            <div class="quiz-info">
              <h3>{{ getQuizTitle(result.quizId) }}</h3>
              <div class="quiz-meta">
                <span class="score"
                  >Score: {{ result.score }}/{{ result.totalQuestions }}</span
                >
                <span class="percentage"
                  >({{
                    ((result.score / result.totalQuestions) * 100).toFixed(1)
                  }}%)</span
                >
                <span class="date">{{ formatDate(result.timestamp) }}</span>
              </div>
            </div>
            <div class="quiz-details">
              <button @click="toggleDetails(result.id)" class="btn-details">
                {{ showDetails[result.id] ? "Hide Details" : "Show Details" }}
              </button>
              <div v-if="showDetails[result.id]" class="detailed-results">
                <div
                  v-for="(answer, index) in result.answers"
                  :key="index"
                  class="answer-item"
                  :class="{
                    correct:
                    getQuizQuestion(result.quizId, index).options[answer] ===
                      getQuizQuestion(result.quizId, index).correctAnswer,
                    incorrect:
                    getQuizQuestion(result.quizId, index).options[answer] !==
                      getQuizQuestion(result.quizId, index).correctAnswer,
                  }"
                >
                  <p class="question-text">
                    {{ getQuizQuestion(result.quizId, index).text }}
                  </p>
                  <div class="answer-info">
                    <p>
                      Your answer:
                      <span
                        :class="{
                          'correct-answer':
                          getQuizQuestion(result.quizId, index).options[answer] ===
                            getQuizQuestion(result.quizId, index).correctAnswer,
                          'incorrect-answer':
                          getQuizQuestion(result.quizId, index).options[answer] !==
                            getQuizQuestion(result.quizId, index).correctAnswer,
                        }"
                      >
                        {{
                          getQuizQuestion(result.quizId, index).options[answer]
                        }}
                      </span>
                    </p>
                    <p
                      v-if="
                        getQuizQuestion(result.quizId, index).options[answer] !==
                        getQuizQuestion(result.quizId, index).correctAnswer
                      "
                    >
                      Correct answer:
                      <span class="correct-answer">
                        {{
                            getQuizQuestion(result.quizId, index).correctAnswer
                        }}
                      </span>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <p v-else class="no-history">No quiz history available.</p>
      </div>

      <div class="statistics">
        <h2>Statistics</h2>
        <div class="stats-grid">
          <div class="stat-item">
            <span class="stat-value">{{ totalQuizzes }}</span>
            <span class="stat-label">Total Quizzes</span>
          </div>
          <div class="stat-item">
            <span class="stat-value">{{ averageScore }}%</span>
            <span class="stat-label">Average Score</span>
          </div>
          <div class="stat-item">
            <span class="stat-value">{{ highestScore }}%</span>
            <span class="stat-label">Highest Score</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, computed, onMounted } from "vue";
import { useStore } from "vuex";
import { collection, query, where, getDocs } from "firebase/firestore";
import { db } from "../firebase/config";

export default {
  name: "UserProfile",
  setup() {
    const store = useStore();
    const user = computed(() => store.state.user.user);
    const quizHistory = ref([]);
    const showDetails = ref({});

    const fetchQuizHistory = async () => {
      try {
        const q = query(
          collection(db, "quizResults"),
          where("userId", "==", user.value.uid)
        );
        const querySnapshot = await getDocs(q);
        quizHistory.value = querySnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
      } catch (error) {
        console.error("Error fetching quiz history:", error);
      }
    };

    const getQuizTitle = (quizId) => {
      const quiz = store.state.quizzes.quizzes.find((q) => q.id === quizId);
      return quiz ? quiz.title : "Unknown Quiz";
    };

    const getQuizQuestion = (quizId, index) => {
      const quiz = store.state.quizzes.quizzes.find((q) => q.id === quizId);
      return quiz ? quiz.questions[index] : null;
    };

    const toggleDetails = (resultId) => {
      showDetails.value[resultId] = !showDetails.value[resultId];
    };

    const formatDate = (timestamp) => {
      return new Date(timestamp.toDate()).toLocaleDateString();
    };

    const totalQuizzes = computed(() => quizHistory.value.length);

    const averageScore = computed(() => {
      if (quizHistory.value.length === 0) return 0;
      const total = quizHistory.value.reduce((sum, result) => {
        return sum + (result.score / result.totalQuestions) * 100;
      }, 0);
      return (total / quizHistory.value.length).toFixed(1);
    });

    const highestScore = computed(() => {
      if (quizHistory.value.length === 0) return 0;
      return Math.max(
        ...quizHistory.value.map(
          (result) => (result.score / result.totalQuestions) * 100
        )
      ).toFixed(1);
    });

    onMounted(async () => {
      await store.dispatch("quizzes/fetchQuizzes");
      await fetchQuizHistory();
    });

    return {
      user,
      quizHistory,
      showDetails,
      getQuizTitle,
      getQuizQuestion,
      toggleDetails,
      formatDate,
      totalQuizzes,
      averageScore,
      highestScore,
    };
  },
};
</script>

<style scoped>
.profile-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
}

.profile-header {
  margin-bottom: 2rem;
}

.profile-header h1 {
  color: var(--primary-color);
  font-size: 2rem;
}

.profile-content {
  display: grid;
  gap: 2rem;
}

.user-info,
.quiz-history,
.statistics {
  background: white;
  padding: 2rem;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.info-item {
  display: flex;
  margin-bottom: 1rem;
}

.label {
  font-weight: bold;
  width: 100px;
  color: #666;
}

.value {
  color: #333;
}

.history-list {
  display: grid;
  gap: 1rem;
}

.history-item {
  border: 1px solid #eee;
  border-radius: 4px;
  padding: 1rem;
}

.quiz-info h3 {
  margin: 0 0 0.5rem 0;
  color: #333;
}

.quiz-meta {
  display: flex;
  gap: 1rem;
  color: #666;
  font-size: 0.9rem;
}

.score {
  font-weight: bold;
  color: var(--primary-color);
}

.btn-details {
  background: none;
  border: 1px solid var(--primary-color);
  color: var(--primary-color);
  padding: 0.5rem 1rem;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-details:hover {
  background-color: var(--primary-color);
  color: white;
}

.detailed-results {
  margin-top: 1rem;
  padding-top: 1rem;
  border-top: 1px solid #eee;
}

.answer-item {
  padding: 1rem;
  margin-bottom: 1rem;
  border-radius: 4px;
}

.answer-item.correct {
  background-color: #d4edda;
  border: 1px solid #c3e6cb;
}

.answer-item.incorrect {
  background-color: #f8d7da;
  border: 1px solid #f5c6cb;
}

.question-text {
  margin: 0 0 0.5rem 0;
  font-weight: bold;
}

.answer-info {
  font-size: 0.9rem;
}

.correct-answer {
  color: #28a745;
  font-weight: bold;
}

.incorrect-answer {
  color: #dc3545;
  font-weight: bold;
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
}

.stat-item {
  text-align: center;
  padding: 1rem;
  background: #f8f9fa;
  border-radius: 4px;
}

.stat-value {
  display: block;
  font-size: 2rem;
  font-weight: bold;
  color: var(--primary-color);
}

.stat-label {
  color: #666;
  font-size: 0.9rem;
}

.no-history {
  text-align: center;
  color: #666;
  padding: 2rem;
}

@media (max-width: 768px) {
  .profile-content {
    grid-template-columns: 1fr;
  }

  .quiz-meta {
    flex-direction: column;
    gap: 0.5rem;
  }

  .stats-grid {
    grid-template-columns: 1fr;
  }
}
</style>
