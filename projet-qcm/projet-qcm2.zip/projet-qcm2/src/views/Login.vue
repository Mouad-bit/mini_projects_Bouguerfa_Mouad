<template>
  <div class="login-container">
    <div class="login-card">
      <div class="card-header">
        <h2>Login</h2>
      </div>
      <div class="card-body">
        <form @submit.prevent="handleLogin">
          <div class="form-group">
            <label for="email">Email</label>
            <input
              type="email"
              id="email"
              v-model="email"
              required
              class="form-input"
            />
          </div>
          <div class="form-group">
            <label for="password">Password</label>
            <input
              type="password"
              id="password"
              v-model="password"
              required
              class="form-input"
            />
          </div>
          <div class="form-actions">
            <button type="submit" class="btn-primary">Login</button>
            <p class="register-link">
              Don't have an account?
              <router-link to="/register">Register</router-link>
            </p>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script>
import { ref } from "vue";
import { useRouter } from "vue-router";
import { useStore } from "vuex";
import { auth } from "../firebase/config";
import { signInWithEmailAndPassword } from "firebase/auth";

export default {
  name: "LoginPage",
  setup() {
    const email = ref("");
    const password = ref("");
    const loading = ref(false);
    const router = useRouter();
    const store = useStore();

    const handleLogin = async () => {
      try {
        loading.value = true;
        const userCredential = await signInWithEmailAndPassword(
          auth,
          email.value,
          password.value
        );
        await store.dispatch("fetchUserProfile", userCredential.user.uid);
        router.push("/quizzes");
      } catch (error) {
        console.error("Error logging in:", error);
        alert("Invalid email or password");
      } finally {
        loading.value = false;
      }
    };

    return {
      email,
      password,
      loading,
      handleLogin,
    };
  },
};
</script>

<style>
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  padding: 2rem;
}

.login-card {
  width: 100%;
  max-width: 500px;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.card-header {
  padding: 1.5rem;
  border-bottom: 1px solid #eee;
}

.card-header h2 {
  margin: 0;
  color: var(--primary-color);
  font-size: 1.5rem;
}

.card-body {
  padding: 1.5rem;
}

.form-group {
  margin-bottom: 1.5rem;
}

.form-group label {
  display: block;
  margin-bottom: 0.5rem;
  color: #333;
}

.form-input {
  width: 100%;
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 1rem;
  transition: border-color 0.3s ease;
}

.form-input:focus {
  outline: none;
  border-color: var(--primary-color);
}

.form-actions {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1rem;
}

.btn-primary {
  width: 100%;
  padding: 0.75rem;
  background-color: var(--primary-color);
  color: white;
  border: none;
  border-radius: 4px;
  font-size: 1rem;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.btn-primary:hover {
  background-color: var(--primary-color-dark);
}

.register-link {
  text-align: center;
  color: #666;
}

.register-link a {
  color: var(--primary-color);
  text-decoration: none;
}

.register-link a:hover {
  text-decoration: underline;
}
</style>
