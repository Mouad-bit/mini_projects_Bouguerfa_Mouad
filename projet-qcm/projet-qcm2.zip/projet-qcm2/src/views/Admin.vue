<template>
  <div class="admin-container">
    <div class="admin-header">
      <h1>Admin Dashboard</h1>
    </div>

    <div class="admin-card">
      <div class="card-header">
        <h2>Create New Quiz</h2>
      </div>
      <div class="card-body">
        <form @submit.prevent="createQuiz">
          <div class="form-row">
            <div class="form-group">
              <label for="title">Quiz Title</label>
              <input
                type="text"
                id="title"
                v-model="newQuiz.title"
                required
                class="form-input"
              />
            </div>
            <div class="form-group">
              <label for="description">Description</label>
              <input
                type="text"
                id="description"
                v-model="newQuiz.description"
                required
                class="form-input"
              />
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label for="category">Category</label>
              <select
                id="category"
                v-model="newQuiz.category"
                required
                class="form-input"
              >
                <option value="">Select a category</option>
                <option v-for="cat in categories" :key="cat" :value="cat">
                  {{ cat }}
                </option>
              </select>
            </div>
            <div class="form-group">
              <label for="difficulty">Difficulty</label>
              <select
                id="difficulty"
                v-model="newQuiz.difficulty"
                required
                class="form-input"
              >
                <option value="">Select difficulty</option>
                <option value="easy">Easy</option>
                <option value="medium">Medium</option>
                <option value="hard">Hard</option>
              </select>
            </div>
          </div>

          <div class="questions-section">
            <h3>Questions</h3>
            <div
              v-for="(question, index) in newQuiz.questions"
              :key="index"
              class="question-card"
            >
              <div class="question-header">
                <h4>Question {{ index + 1 }}</h4>
                <button
                  type="button"
                  class="btn-danger"
                  @click="removeQuestion(index)"
                >
                  Remove
                </button>
              </div>
              <div class="question-body">
                <div class="form-group">
                  <label :for="'question-' + index">Question Text</label>
                  <input
                    :id="'question-' + index"
                    v-model="question.text"
                    required
                    class="form-input"
                  />
                </div>
                <div class="options-group">
                  <div
                    v-for="(option, optIndex) in question.options"
                    :key="optIndex"
                    class="option-input"
                  >
                    <input
                      type="radio"
                      :name="'correct-' + index"
                      :value="optIndex"
                      v-model="question.correctAnswer"
                      required
                    />
                    <input
                      type="text"
                      v-model="question.options[optIndex]"
                      required
                      class="form-input"
                      placeholder="Option"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div class="question-actions">
              <button
                type="button"
                class="btn-success"
                @click="fetchQuestions"
                :disabled="!newQuiz.category || !newQuiz.difficulty"
              >
                Fetch Questions
              </button>
              <button type="button" class="btn-primary" @click="addQuestion">
                Add Question
              </button>
            </div>
          </div>

          <div class="form-actions">
            <button type="submit" class="btn-primary" :disabled="loading">
              {{ loading ? "Creating..." : "Create Quiz" }}
            </button>
            <button type="button" class="btn-secondary" @click="resetForm">
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>

    <div class="quizzes-list">
      <h2>Existing Quizzes</h2>
      <div v-for="quiz in quizzes" :key="quiz.id" class="quiz-card">
        <div class="quiz-header">
          <h3>{{ quiz.title }}</h3>
          <button class="btn-danger" @click="deleteQuiz(quiz.id)">
            Delete
          </button>
        </div>
        <div class="quiz-body">
          <p>{{ quiz.description }}</p>
          <div class="quiz-meta">
            <span>Category: {{ quiz.category }}</span>
            <span>Difficulty: {{ quiz.difficulty }}</span>
            <span>Questions: {{ quiz.questions.length }}</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, computed, onMounted } from "vue";
import { useStore } from "vuex";
import { collection, addDoc, deleteDoc, doc } from "firebase/firestore";
import { db } from "../firebase/config";

export default {
  name: "AdminDashboard",
  setup() {
    const store = useStore();
    const loading = ref(false);
    const categories = [
      "General Knowledge",
      "Science",
      "History",
      "Geography",
      "Sports",
      "Entertainment",
    ];
    const difficulties = ["Easy", "Medium", "Hard"];

    const newQuiz = ref({
      title: "",
      description: "",
      category: "",
      difficulty: "",
      questions: [],
    });

    const fetchQuestions = async () => {
      try {
        const response = await fetch(
          `https://opentdb.com/api.php?amount=10&category=${getCategoryId(
            newQuiz.value.category
          )}&difficulty=${newQuiz.value.difficulty.toLowerCase()}&type=multiple`
        );
        const data = await response.json();

        if (data.results && data.results.length > 0) {
          const decodedQuestions = data.results.map((question) => {
            // Decode HTML entities in the question and answers
            const decodeHtml = (html) => {
              const txt = document.createElement("textarea");
              txt.innerHTML = html;
              return txt.value;
            };

            const correctAnswer = decodeHtml(question.correct_answer);
            const options = [
              ...question.incorrect_answers.map(decodeHtml),
              correctAnswer,
            ].sort(() => Math.random() - 0.5);

            // Find the index of the correct answer in the shuffled options
            const correctAnswerIndex = options.findIndex(
              (option) => option === correctAnswer
            );

            return {
              text: decodeHtml(question.question),
              options: options,
              correctAnswer: correctAnswerIndex.toString(), // Convert to string to match radio input value
            };
          });

          // Add new questions to existing ones
          newQuiz.value.questions = [
            ...newQuiz.value.questions,
            ...decodedQuestions,
          ];
        }
      } catch (error) {
        console.error("Error fetching questions:", error);
        alert("Failed to fetch questions. Please try again.");
      }
    };

    const getCategoryId = (category) => {
      const categoryMap = {
        "General Knowledge": 9,
        Science: 17,
        History: 23,
        Geography: 22,
        Sports: 21,
        Entertainment: 11,
      };
      return categoryMap[category] || 9;
    };

    const addQuestion = () => {
      newQuiz.value.questions.push({
        text: "",
        options: ["", "", "", ""],
        correctAnswer: "",
      });
    };

    const removeQuestion = (index) => {
      if (confirm("Are you sure you want to delete this question?")) {
        newQuiz.value.questions.splice(index, 1);
      }
    };

    const createQuiz = async () => {
      try {
        if (
          !newQuiz.value.title ||
          !newQuiz.value.description ||
          !newQuiz.value.category ||
          !newQuiz.value.difficulty ||
          newQuiz.value.questions.length === 0
        ) {
          alert("Please fill in all fields and add at least one question");
          return;
        }

        await addDoc(collection(db, "quizzes"), {
          ...newQuiz.value,
          createdAt: new Date(),
        });

        alert("Quiz created successfully!");
        resetForm();
      } catch (error) {
        console.error("Error creating quiz:", error);
        alert("Error creating quiz. Please try again.");
      }
    };

    const deleteQuiz = async (quizId) => {
      if (!confirm("Are you sure you want to delete this quiz?")) return;

      try {
        await deleteDoc(doc(db, "quizzes", quizId));
        await store.dispatch("quizzes/fetchQuizzes");
      } catch (error) {
        console.error("Error deleting quiz:", error);
        alert("Failed to delete quiz. Please try again.");
      }
    };

    const resetForm = () => {
      newQuiz.value = {
        title: "",
        description: "",
        category: "",
        difficulty: "",
        questions: [],
      };
    };

    onMounted(() => {
      store.dispatch("quizzes/fetchQuizzes");
    });

    return {
      loading,
      categories,
      difficulties,
      newQuiz,
      quizzes: computed(() => store.state.quizzes.quizzes),
      addQuestion,
      removeQuestion,
      createQuiz,
      deleteQuiz,
      fetchQuestions,
      resetForm,
    };
  },
};
</script>

<style>
.admin-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
}

.admin-header {
  margin-bottom: 2rem;
}

.admin-header h1 {
  color: var(--primary-color);
  font-size: 2rem;
}

.admin-card {
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  margin-bottom: 2rem;
}

.card-header {
  padding: 1.5rem;
  border-bottom: 1px solid #eee;
}

.card-header h2 {
  margin: 0;
  color: var(--primary-color);
  font-size: 1.5rem;
}

.card-body {
  padding: 1.5rem;
}

.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
  margin-bottom: 1.5rem;
}

.form-group {
  margin-bottom: 1rem;
}

.form-group label {
  display: block;
  margin-bottom: 0.5rem;
  color: #333;
}

.form-input {
  width: 100%;
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 1rem;
  transition: border-color 0.3s ease;
}

.form-input:focus {
  outline: none;
  border-color: var(--primary-color);
}

.questions-section {
  margin: 2rem 0;
}

.questions-section h3 {
  margin-bottom: 1rem;
  color: #333;
}

.question-card {
  background: #f8f9fa;
  border-radius: 4px;
  padding: 1rem;
  margin-bottom: 1rem;
}

.question-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
}

.question-header h4 {
  margin: 0;
  color: #333;
}

.options-group {
  display: grid;
  gap: 0.5rem;
}

.option-input {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.option-input input[type="radio"] {
  margin: 0;
}

.form-actions {
  display: flex;
  gap: 1rem;
  margin-top: 2rem;
}

.btn-primary {
  padding: 0.75rem 1.5rem;
  background-color: var(--primary-color);
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.btn-primary:hover:not(:disabled) {
  background-color: var(--primary-color-dark);
}

.btn-primary:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.btn-secondary {
  padding: 0.75rem 1.5rem;
  background-color: white;
  color: var(--primary-color);
  border: 1px solid var(--primary-color);
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-secondary:hover {
  background-color: rgba(var(--primary-color-rgb), 0.05);
}

.btn-success {
  padding: 0.75rem 1.5rem;
  background-color: #28a745;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.btn-success:hover {
  background-color: #218838;
}

.btn-danger {
  padding: 0.5rem 1rem;
  background-color: #dc3545;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.btn-danger:hover {
  background-color: #c82333;
}

.quizzes-list {
  margin-top: 2rem;
}

.quizzes-list h2 {
  margin-bottom: 1rem;
  color: var(--primary-color);
}

.quiz-card {
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  margin-bottom: 1rem;
  overflow: hidden;
}

.quiz-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem;
  background-color: #f8f9fa;
}

.quiz-header h3 {
  margin: 0;
  color: #333;
}

.quiz-body {
  padding: 1rem;
}

.quiz-meta {
  display: flex;
  gap: 1rem;
  margin-top: 0.5rem;
  color: #666;
  font-size: 0.9rem;
}

.question-actions {
  display: flex;
  gap: 1rem;
  margin: 1rem 0;
}

@media (max-width: 768px) {
  .form-row {
    grid-template-columns: 1fr;
  }

  .quiz-meta {
    flex-direction: column;
    gap: 0.5rem;
  }
}
</style>
