<template>
  <div class="leaderboard-container">
    <div class="leaderboard-header">
      <h2>Leaderboard</h2>
      <p class="subtitle">Track your progress and compete with others</p>
    </div>

    <div class="quiz-filter">
      <label for="quiz-select" class="filter-label">Filter by Quiz</label>
      <select id="quiz-select" v-model="selectedQuiz" class="quiz-select">
        <option value="">All Quizzes</option>
        <option v-for="quiz in quizzes" :key="quiz.id" :value="quiz.id">
          {{ quiz.title }}
        </option>
      </select>
    </div>

    <div v-if="loading" class="loading-container">
      <div class="spinner"></div>
      <p>Loading leaderboard...</p>
    </div>

    <div v-else class="table-wrapper">
      <table class="leaderboard-table">
        <thead>
          <tr>
            <th class="rank-header">Rank</th>
            <th>User</th>
            <th>Quiz</th>
            <th class="score-header">Score</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="(result, index) in filteredResults"
            :key="result.id"
            :class="{ 'top-three': index < 3 }"
          >
            <td class="rank-cell">
              <span class="rank-number">{{ index + 1 }}</span>
              <span v-if="index < 3" class="medal">🏆</span>
            </td>
            <td class="user-cell">{{ result.userEmail }}</td>
            <td class="quiz-cell">{{ getQuizTitle(result.quizId) }}</td>
            <td class="score-cell">
              <div class="score-wrapper">
                <span class="score-value">{{ result.score }}</span>
                <span class="score-divider">/</span>
                <span class="score-total">{{ result.totalQuestions }}</span>
              </div>
            </td>
            <td class="date-cell">{{ formatDate(result.timestamp) }}</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
import { ref, computed, onMounted, watch } from "vue";
import { useStore } from "vuex";
import {
  collection,
  query,
  where,
  getDocs,
  getDoc,
  doc,
  orderBy,
} from "firebase/firestore";
import { db } from "../firebase/config";

export default {
  name: "QuizLeaderboard",
  setup() {
    const store = useStore();
    const selectedQuiz = ref("");
    const results = ref([]);
    const users = ref({});
    const loading = ref(true);

    const loadResults = async () => {
      try {
        loading.value = true;
        let resultsQuery = collection(db, "quizResults");

        if (selectedQuiz.value) {
          resultsQuery = query(
            resultsQuery,
            where("quizId", "==", selectedQuiz.value)
          );
        }

        // Add ordering by score and timestamp
        resultsQuery = query(
          resultsQuery,
          orderBy("score", "desc"),
          orderBy("timestamp", "desc")
        );

        const resultsSnapshot = await getDocs(resultsQuery);
        const resultsData = [];

        for (const resultDoc of resultsSnapshot.docs) {
          const result = { id: resultDoc.id, ...resultDoc.data() };

          // Get user email if not already cached
          if (!users.value[result.userId]) {
            const userDoc = await getDoc(doc(db, "users", result.userId));
            if (userDoc.exists()) {
              users.value[result.userId] = userDoc.data().email;
            }
          }

          result.userEmail = users.value[result.userId] || "Unknown User";
          resultsData.push(result);
        }

        results.value = resultsData;
      } catch (error) {
        console.error("Error loading results:", error);
      } finally {
        loading.value = false;
      }
    };

    const filteredResults = computed(() => {
      return [...results.value].sort((a, b) => {
        const scoreA = a.score / a.totalQuestions;
        const scoreB = b.score / b.totalQuestions;
        if (scoreA === scoreB) {
          return (
            b.timestamp.toDate().getTime() - a.timestamp.toDate().getTime()
          );
        }
        return scoreB - scoreA;
      });
    });

    const getQuizTitle = (quizId) => {
      const quiz = store.state.quizzes.quizzes.find((q) => q.id === quizId);
      return quiz ? quiz.title : "Unknown Quiz";
    };

    const formatDate = (timestamp) => {
      if (!timestamp) return "";
      const date = timestamp.toDate();
      return date.toLocaleDateString() + " " + date.toLocaleTimeString();
    };

    onMounted(async () => {
      await store.dispatch("quizzes/fetchQuizzes");
      await loadResults();
    });

    // Add a watcher for quizzes to reload results when quizzes are updated
    watch(
      () => store.state.quizzes.quizzes,
      () => {
        loadResults();
      }
    );

    return {
      selectedQuiz,
      quizzes: computed(() => store.state.quizzes.quizzes),
      filteredResults,
      getQuizTitle,
      formatDate,
      loading,
      loadResults,
    };
  },
  watch: {
    selectedQuiz() {
      this.loadResults();
    },
  },
};
</script>

<style scoped>
.leaderboard-container {
  max-width: 1200px;
  margin: 2rem auto;
  padding: 2rem;
  background: #fff;
  border-radius: 16px;
  box-shadow: 0 8px 30px rgba(0, 0, 0, 0.08);
}

.leaderboard-header {
  text-align: center;
  margin-bottom: 2.5rem;
}

h2 {
  color: var(--dark-color);
  font-size: 2.5rem;
  font-weight: 700;
  margin-bottom: 0.5rem;
  background: linear-gradient(45deg, var(--primary-color), #4a90e2);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

.subtitle {
  color: var(--secondary-color);
  font-size: 1.1rem;
  margin-top: 0.5rem;
}

.quiz-filter {
  margin-bottom: 2.5rem;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
}

.filter-label {
  color: var(--dark-color);
  font-weight: 600;
  font-size: 1rem;
}

.quiz-select {
  padding: 0.875rem 1.5rem;
  border: 2px solid var(--primary-color);
  border-radius: 12px;
  background-color: white;
  color: var(--dark-color);
  font-size: 1rem;
  cursor: pointer;
  transition: all 0.3s ease;
  width: 350px;
  max-width: 100%;
  appearance: none;
  background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e");
  background-repeat: no-repeat;
  background-position: right 1rem center;
  background-size: 1em;
}

.quiz-select:focus {
  outline: none;
  box-shadow: 0 0 0 4px rgba(13, 110, 253, 0.15);
  border-color: var(--primary-color);
}

.table-wrapper {
  overflow-x: auto;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
  background: white;
}

.leaderboard-table {
  width: 100%;
  border-collapse: separate;
  border-spacing: 0;
  background: white;
  border-radius: 12px;
  overflow: hidden;
}

.leaderboard-table th {
  background-color: var(--primary-color);
  color: white;
  padding: 1.25rem 1.5rem;
  text-align: left;
  font-weight: 600;
  text-transform: uppercase;
  font-size: 0.875rem;
  letter-spacing: 0.5px;
  position: sticky;
  top: 0;
  z-index: 1;
}

.leaderboard-table th:first-child {
  border-top-left-radius: 12px;
}

.leaderboard-table th:last-child {
  border-top-right-radius: 12px;
}

.leaderboard-table td {
  padding: 1.25rem 1.5rem;
  border-bottom: 1px solid #f0f0f0;
  color: var(--dark-color);
  transition: background-color 0.2s ease;
}

.leaderboard-table tr:last-child td {
  border-bottom: none;
}

.leaderboard-table tr:hover {
  background-color: #f8f9fa;
}

.leaderboard-table tr.top-three {
  background-color: #fff9e6;
}

.rank-cell {
  font-weight: bold;
  width: 100px;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.rank-number {
  font-size: 1.25rem;
  color: var(--primary-color);
}

.medal {
  font-size: 1.5rem;
}

.user-cell {
  font-weight: 500;
}

.quiz-cell {
  color: var(--secondary-color);
}

.score-cell {
  width: 120px;
}

.score-wrapper {
  display: flex;
  align-items: center;
  gap: 0.25rem;
}

.score-value {
  font-weight: 700;
  color: var(--success-color);
}

.score-divider {
  color: var(--secondary-color);
}

.score-total {
  color: var(--secondary-color);
}

.date-cell {
  color: var(--secondary-color);
  white-space: nowrap;
}

@media (max-width: 768px) {
  .leaderboard-container {
    margin: 1rem;
    padding: 1.5rem;
  }

  h2 {
    font-size: 2rem;
  }

  .quiz-select {
    width: 100%;
  }

  .leaderboard-table th,
  .leaderboard-table td {
    padding: 1rem;
    font-size: 0.875rem;
  }

  .rank-number {
    font-size: 1.1rem;
  }

  .medal {
    font-size: 1.25rem;
  }
}

@media (max-width: 480px) {
  .leaderboard-container {
    margin: 0.5rem;
    padding: 1rem;
  }

  h2 {
    font-size: 1.75rem;
  }

  .subtitle {
    font-size: 1rem;
  }

  .leaderboard-table th,
  .leaderboard-table td {
    padding: 0.75rem;
  }
}

.loading-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 2rem;
  gap: 1rem;
}

.spinner {
  width: 40px;
  height: 40px;
  border: 4px solid #f3f3f3;
  border-top: 4px solid var(--primary-color);
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}
</style>
