import { doc, setDoc, getDoc } from "firebase/firestore";
import { db } from "../../firebase/config";
import { getAuth, onAuthStateChanged } from "firebase/auth";

export default {
  namespaced: true,
  state: {
    user: null,
    loading: true,
  },
  mutations: {
    setUser(state, user) {
      state.user = user;
    },
    setLoading(state, loading) {
      state.loading = loading;
    },
  },
  actions: {
    async createUserProfile({ commit }, { uid, email, name }) {
      try {
        console.log("Creating user profile for:", uid);

        // Create user profile in Firestore
        const userData = {
          email,
          name,
          role: email === "admin@quizapp.com" ? "admin" : "user",
          createdAt: new Date(),
          lastLogin: new Date(),
        };

        console.log("Setting user document in Firestore...");
        const userRef = doc(db, "users", uid);
        await setDoc(userRef, userData);
        console.log("User document created in Firestore");

        // Set user in store
        console.log("Updating Vuex store with user data...");
        commit("setUser", {
          uid,
          ...userData,
        });
        console.log("Vuex store updated with user data");
      } catch (error) {
        console.error("Error creating user profile:", error);
        throw new Error("Failed to create user profile: " + error.message);
      }
    },
    async fetchUserProfile({ commit }, uid) {
      try {
        console.log("Fetching user profile for:", uid);
        const userRef = doc(db, "users", uid);
        const userDoc = await getDoc(userRef);

        if (userDoc.exists()) {
          console.log("User profile found, updating store...");
          const userData = userDoc.data();

          // Get the user's custom claims
          const auth = getAuth();
          const currentUser = auth.currentUser;
          if (currentUser) {
            const tokenResult = await currentUser.getIdTokenResult();
            const role = tokenResult.claims.role || userData.role;
            userData.role = role;
          }

          commit("setUser", { uid, ...userData });
        } else {
          console.error("User profile not found in Firestore");
          throw new Error("User profile not found");
        }
      } catch (error) {
        console.error("Error fetching user profile:", error);
        throw error;
      }
    },
    async updateUserRole({ commit }, { uid, role }) {
      try {
        console.log("Updating user role for:", uid);
        const userRef = doc(db, "users", uid);
        await setDoc(userRef, { role }, { merge: true });

        // Update the user in the store
        const userDoc = await getDoc(userRef);
        if (userDoc.exists()) {
          commit("setUser", { uid, ...userDoc.data() });
        }
      } catch (error) {
        console.error("Error updating user role:", error);
        throw error;
      }
    },
    initAuth({ commit, dispatch }) {
      console.log("Initializing auth state...");
      const auth = getAuth();
      commit("setLoading", true);

      onAuthStateChanged(auth, async (user) => {
        console.log("Auth state changed, user:", user?.uid);
        if (user) {
          try {
            await dispatch("fetchUserProfile", user.uid);
          } catch (error) {
            console.error(
              "Error fetching user profile after auth change:",
              error
            );
          }
        } else {
          commit("setUser", null);
        }
        commit("setLoading", false);
      });
    },
  },
  getters: {
    isAuthenticated: (state) => state.user !== null,
    currentUser: (state) => state.user,
    isLoading: (state) => state.loading,
  },
};
