import { collection, getDocs } from "firebase/firestore";
import { db } from "../../firebase/config";

export default {
  namespaced: true,
  state: {
    quizzes: [],
    loading: false,
    error: null,
  },
  mutations: {
    setQuizzes(state, quizzes) {
      state.quizzes = quizzes;
    },
    setLoading(state, loading) {
      state.loading = loading;
    },
    setError(state, error) {
      state.error = error;
    },
  },
  actions: {
    async fetchQuizzes({ commit }) {
      try {
        commit("setLoading", true);
        commit("setError", null);

        const quizzesSnapshot = await getDocs(collection(db, "quizzes"));
        const quizzes = quizzesSnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));

        commit("setQuizzes", quizzes);
      } catch (error) {
        console.error("Error fetching quizzes:", error);
        commit("setError", "Failed to load quizzes");
        throw error;
      } finally {
        commit("setLoading", false);
      }
    },
  },
  getters: {
    allQuizzes: (state) => state.quizzes,
    activeQuizzes: (state) => state.quizzes.filter((quiz) => quiz.isActive),
    loading: (state) => state.loading,
    error: (state) => state.error,
  },
};
