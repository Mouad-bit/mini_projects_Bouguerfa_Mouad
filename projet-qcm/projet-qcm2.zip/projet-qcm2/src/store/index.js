import { createStore } from "vuex";
import quizzes from "./modules/quizzes";
import user from "./modules/user";

export default createStore({
  modules: {
    quizzes,
    user,
  },
});
