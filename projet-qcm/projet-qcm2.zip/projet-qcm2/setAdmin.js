const admin = require("firebase-admin");
const serviceAccount = require("./serviceAccountKey.json");

// Initialize Firebase Admin
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

// Array of admin emails
const adminEmails = [
  "admin@quizapp.com",
  // Add more admin emails here
  // "another.admin@example.com",
  // "third.admin@example.com"
];

async function setAdminRole() {
  try {
    for (const email of adminEmails) {
      const user = await admin.auth().getUserByEmail(email);
      await admin.auth().setCustomUserClaims(user.uid, { role: "admin" });
      console.log(`Successfully set admin role for user: ${email}`);
    }
    console.log("All admin roles have been set successfully!");
  } catch (error) {
    console.error("Error setting admin role:", error);
  }
}

setAdminRole();
