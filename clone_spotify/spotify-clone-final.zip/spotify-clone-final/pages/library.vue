<script setup lang="ts">
import { ref, onMounted, watch } from 'vue'
import { useAuthStore } from '~/stores/auth'
import { usePlayerStore } from '~/stores/player'

const authStore = useAuthStore()
const playerStore = usePlayerStore()
const playlists = ref<any[]>([])
const selectedPlaylist = ref<any>(null)
const playlistTracks = ref<any[]>([])
const isLoading = ref(false)
const newPlaylistName = ref('')
const newPlaylistDesc = ref('')
const errorMsg = ref('')
const refreshCounter = ref(0)

const fetchPlaylists = async () => {
  isLoading.value = true
  try {
    if (authStore.spotifyApi) {
      const response = await authStore.spotifyApi.getUserPlaylists({
        limit: 50,
        fields: 'items(id,name,images,tracks(total),owner,public)'
      })
      
      playlists.value = response.body.items.map(playlist => ({
        ...playlist,
        tracks: {
          total: playlist.tracks?.total || 0
        }
      }))
      errorMsg.value = ''
    }
  } catch (error) {
    errorMsg.value = 'Failed to load playlists.'
    console.error('Error fetching playlists:', error)
  } finally {
    isLoading.value = false
  }
}

const fetchPlaylistTracks = async (playlistId: string) => {
  isLoading.value = true
  try {
    if (authStore.spotifyApi) {
      const playlistResponse = await authStore.spotifyApi.getPlaylist(playlistId, {
        fields: 'id,name,images,tracks(total)'
      })
      
      const trackResponse = await authStore.spotifyApi.getPlaylistTracks(playlistId, {
        limit: 100,
        fields: 'total,items(track(id,name,uri,artists,album(images)))'
      })
      
      playlistTracks.value = trackResponse.body.items
      
      if (selectedPlaylist.value && selectedPlaylist.value.id === playlistId) {
        selectedPlaylist.value = {
          ...selectedPlaylist.value,
          tracks: {
            total: playlistResponse.body.tracks.total
          }
        }
      }
      
      const playlistIndex = playlists.value.findIndex(p => p.id === playlistId)
      if (playlistIndex !== -1) {
        playlists.value[playlistIndex] = {
          ...playlists.value[playlistIndex],
          tracks: {
            total: playlistResponse.body.tracks.total
          }
        }
      }
      
      errorMsg.value = ''
    }
  } catch (error) {
    errorMsg.value = 'Failed to load playlist tracks.'
    console.error('Error fetching playlist tracks:', error)
  } finally {
    isLoading.value = false
  }
}

const selectPlaylist = async (playlist: any) => {
  if (selectedPlaylist.value?.id === playlist.id) return
  
  selectedPlaylist.value = JSON.parse(JSON.stringify(playlist))
  await fetchPlaylistTracks(playlist.id)
  await fetchPlaylists()
}

const createPlaylist = async () => {
  if (!newPlaylistName.value.trim()) return
  try {
    if (authStore.spotifyApi && authStore.user) {
      await authStore.spotifyApi.createPlaylist(authStore.user.id, {
        name: newPlaylistName.value,
        description: newPlaylistDesc.value,
        public: false
      })
      newPlaylistName.value = ''
      newPlaylistDesc.value = ''
      await fetchPlaylists()
      alert('Playlist created!')
    }
  } catch (error) {
    alert('Failed to create playlist.')
    console.error(error)
  }
}

const removeTrack = async (trackUri: string) => {
  if (!selectedPlaylist.value) return
  try {
    await authStore.spotifyApi.removeTracksFromPlaylist(
      selectedPlaylist.value.id, 
      [{ uri: trackUri }]
    )
    
    refreshCounter.value++
    await fetchPlaylistTracks(selectedPlaylist.value.id)
    await fetchPlaylists()
  } catch (error) {
    alert('Failed to remove track.')
    console.error('Error removing track:', error)
  }
}

const getPlaylistImage = (playlist: any) => {
  if (playlist.images && playlist.images.length > 0) {
    return playlist.images[0].url
  }
  return '/placeholder-album.png'
}

const deletePlaylist = async (playlistId: string) => {
  if (!confirm('Are you sure you want to delete this playlist?')) return
  
  try {
    if (authStore.spotifyApi) {
      await authStore.spotifyApi.unfollowPlaylist(playlistId)
      playlists.value = playlists.value.filter(p => p.id !== playlistId)
      
      if (selectedPlaylist.value?.id === playlistId) {
        selectedPlaylist.value = null
        playlistTracks.value = []
      }
      
      await fetchPlaylists()
      alert('Playlist deleted successfully')
    }
  } catch (error) {
    console.error('Error deleting playlist:', error)
    alert('Failed to delete playlist')
  }
}

const getTrackImage = (item: any) => {
  if (item.track && item.track.album && item.track.album.images && item.track.album.images.length > 0) {
    return item.track.album.images[0].url
  }
  return '/placeholder-album.png'
}

const playTrack = async (trackUri: string) => {
  try {
    if (!playerStore.player) {
      await playerStore.initializePlayer()
    }

    await playerStore.player.play({
      uris: [trackUri]
    })

    playerStore.setIsPlaying(true)
    const currentTrack = playlistTracks.value.find(item => item.track.uri === trackUri)?.track
    playerStore.setCurrentTrack(currentTrack || null)
    
  } catch (error) {
    console.error('Error playing track:', error)
    const trackId = trackUri.split(':')[2]
    if (trackId) {
      window.open(`https://open.spotify.com/track/${trackId}`, '_blank')
    } else {
      alert('Could not play track. Please try again.')
    }
  }
}

watch(refreshCounter, () => {
  fetchPlaylists()
  if (selectedPlaylist.value) {
    fetchPlaylistTracks(selectedPlaylist.value.id)
  }
})

const refreshAll = async () => {
  refreshCounter.value++
}

onMounted(async () => {
  await fetchPlaylists()
})
</script>

<template>
  <div class="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-black p-6">
    <div class="max-w-7xl mx-auto">
      <div class="mb-8">
        <h1 class="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-600 text-transparent bg-clip-text mb-4">Your Music Collection</h1>
        <p class="text-gray-300">Create and manage your playlists</p>
      </div>

      <div class="bg-black/30 backdrop-blur-lg rounded-xl p-6 mb-8 shadow-xl">
        <h2 class="text-2xl font-semibold text-purple-400 mb-4">Create New Playlist</h2>
        <div class="space-y-4">
          <input
            v-model="newPlaylistName"
            type="text"
            placeholder="Playlist Name"
            class="w-full px-4 py-2 rounded-lg bg-gray-800/50 border border-purple-500/30 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 text-white placeholder-gray-400 transition-all duration-300"
          />
          <input
            v-model="newPlaylistDesc"
            type="text"
            placeholder="Description (optional)"
            class="w-full px-4 py-2 rounded-lg bg-gray-800/50 border border-purple-500/30 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 text-white placeholder-gray-400 transition-all duration-300"
          />
          <button
            @click="createPlaylist"
            class="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold py-2 px-6 rounded-lg transition-all duration-300 transform hover:scale-105"
          >
            Create Playlist
          </button>
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div
          v-for="playlist in playlists"
          :key="playlist.id"
          @click="selectPlaylist(playlist)"
          class="bg-black/30 backdrop-blur-lg rounded-xl p-4 cursor-pointer transform hover:scale-105 transition-all duration-300 shadow-xl hover:shadow-purple-500/20"
        >
          <div class="relative aspect-square mb-4 rounded-lg overflow-hidden">
            <img
              :src="getPlaylistImage(playlist)"
              :alt="playlist.name"
              class="w-full h-full object-cover"
            />
            <div class="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
          </div>
          <h3 class="text-xl font-semibold text-white mb-2">{{ playlist.name }}</h3>
          <p class="text-gray-400">{{ playlist.tracks.total }} tracks</p>
        </div>
      </div>

      <div v-if="selectedPlaylist" class="mt-8 bg-black/30 backdrop-blur-lg rounded-xl p-6 shadow-xl">
        <div class="flex justify-between items-center mb-6">
          <h2 class="text-2xl font-semibold text-purple-400">{{ selectedPlaylist.name }}</h2>
          <button
            @click="deletePlaylist(selectedPlaylist.id)"
            class="text-red-400 hover:text-red-300 transition-colors duration-300"
          >
            Delete Playlist
          </button>
        </div>
        
        <div class="space-y-4">
          <div
            v-for="item in playlistTracks"
            :key="item.track.id"
            class="flex items-center justify-between p-4 bg-gray-800/30 rounded-lg hover:bg-gray-800/50 transition-colors duration-300"
          >
            <div class="flex items-center space-x-4">
              <img
                :src="item.track.album.images[0]?.url"
                :alt="item.track.name"
                class="w-12 h-12 rounded"
              />
              <div>
                <h4 class="text-white font-medium">{{ item.track.name }}</h4>
                <p class="text-gray-400 text-sm">
                  {{ item.track.artists.map((artist: any) => artist.name).join(', ') }}
                </p>
              </div>
            </div>
            <div class="flex items-center space-x-4">
              <button
                @click="playerStore.play(item.track.uri)"
                class="text-purple-400 hover:text-purple-300 transition-colors duration-300"
              >
                Play
              </button>
              <button
                @click="removeTrack(item.track.uri)"
                class="text-red-400 hover:text-red-300 transition-colors duration-300"
              >
                Remove
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style>
.btn-spotify {
  background-color: #22c55e;
  color: white;
  font-weight: bold;
  padding: 0.5rem 1rem;
  border-radius: 9999px;
  transition: background-color 200ms ease-in-out;
  box-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
}

.btn-spotify:hover {
  background-color: #16a34a;
}

.main-content {
  min-height: calc(100vh - 150px);
  padding-bottom: 80px;
}

ul {
  max-height: 60vh;
  overflow-y: auto;
  padding-right: 8px;
}

ul::-webkit-scrollbar {
  width: 6px;
}

ul::-webkit-scrollbar-track {
  background: #1e1e1e;
}

ul::-webkit-scrollbar-thumb {
  background: #535353;
  border-radius: 3px;
}
</style>
