<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useAuthStore } from '~/stores/auth'

const searchQuery = ref('')
const searchResults = ref<any[]>([])
const isLoading = ref(false)
const authStore = useAuthStore()

const playlists = ref<any[]>([])
const showDropdown = ref<string | null>(null)
const playlistsError = ref('')

const getImageUrl = (item: any) => {
  if (item.type === 'track' && item.album && item.album.images && item.album.images.length > 0) {
    return item.album.images[0].url
  } else if (item.images && item.images.length > 0) {
    return item.images[0].url
  }
  return '/placeholder-album.png'
}

onMounted(async () => {
  await loadPlaylists()
})

const loadPlaylists = async () => {
  if (authStore.spotifyApi && authStore.isAuthenticated) {
    try {
      const response = await authStore.spotifyApi.getUserPlaylists()
      playlists.value = response.body.items
      playlistsError.value = ''
    } catch (error) {
      playlistsError.value = 'Failed to load playlists. Please re-login or check your permissions.'
      console.error('Error fetching playlists:', error)
    }
  } else {
    playlistsError.value = 'You must be logged in to load playlists.'
  }
}

const handleSearch = async () => {
  if (!searchQuery.value.trim()) {
    searchResults.value = []
    return
  }

  isLoading.value = true
  try {
    if (authStore.spotifyApi) {
      const results = await authStore.spotifyApi.search(searchQuery.value, ['track', 'artist', 'album'], { limit: 20 })
      searchResults.value = [
        ...results.body.tracks?.items || [],
        ...results.body.artists?.items || [],
        ...results.body.albums?.items || []
      ]
    }
  } catch (error) {
    console.error('Search error:', error)
  } finally {
    isLoading.value = false
  }
}

const addToPlaylist = async (playlistId: string, trackUri: string) => {
  if (!authStore.spotifyApi) {
    alert('Spotify API not initialized. Please log in again.')
    return
  }
  try {
    await authStore.spotifyApi.addTracksToPlaylist(playlistId, [trackUri])
    alert('Track added to playlist!')
    showDropdown.value = null

    const playlist = playlists.value.find(p => p.id === playlistId)
    if (playlist) {
      playlist.tracks.total += 1
    }
  } catch (error: any) {
    let message = 'Failed to add track to playlist.'
    if (error && error.body && error.body.error && error.body.error.message) {
      message += '\n' + error.body.error.message
    }
    alert(message)
    console.error('Add to playlist error:', error)
  }
}
</script>

<template>
  <div class="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-black p-6">
    <div class="max-w-7xl mx-auto">
      <div class="mb-8">
        <h1 class="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-600 text-transparent bg-clip-text mb-4">Discover Music</h1>
        <p class="text-gray-300">Search for your favorite songs, artists, and albums</p>
      </div>

      <div class="relative mb-8">
        <input
          v-model="searchQuery"
          type="text"
          placeholder="Search for songs, artists, or albums..."
          class="w-full px-6 py-4 bg-black/30 backdrop-blur-lg rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500 border border-purple-500/30 transition-all duration-300"
          @input="handleSearch"
        />
        <span class="material-icons absolute right-6 top-4 text-purple-400">search</span>
      </div>

      <div v-if="playlistsError" class="text-center text-red-400 py-4 bg-red-500/10 rounded-xl mb-8">
        {{ playlistsError }}
      </div>
      <div v-else-if="playlists.length === 0 && authStore.isAuthenticated" class="text-center text-yellow-400 py-4 bg-yellow-500/10 rounded-xl mb-8">
        No playlists loaded. Try refreshing or check your account permissions.
      </div>

      <div v-if="isLoading" class="flex justify-center py-12">
        <div class="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-500"></div>
      </div>

      <div v-else-if="searchResults.length > 0" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div
          v-for="item in searchResults"
          :key="item.id"
          class="bg-black/30 backdrop-blur-lg rounded-xl p-6 hover:shadow-xl hover:shadow-purple-500/20 transition-all duration-300 transform hover:scale-105"
        >
          <div class="relative aspect-square rounded-lg mb-4 overflow-hidden">
            <img 
              :src="getImageUrl(item)" 
              :alt="item.name" 
              class="w-full h-full object-cover"
              @error="$event.target.src = '/placeholder-album.png'"
            />
            <div class="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
          </div>
          <h3 class="text-xl font-semibold text-white mb-2">{{ item.name }}</h3>
          <p class="text-gray-400 mb-4">
            <span v-if="item.type === 'track' && item.artists">
              {{ item.artists.map(a => a.name).join(', ') }}
            </span>
            <span v-else-if="item.type === 'album' && item.artists">
              {{ item.artists.map(a => a.name).join(', ') }}
            </span>
            <span v-else>
              {{ item.type }}
            </span>
          </p>
          
          <div class="space-y-3">
            <a
              v-if="item.type === 'track' && item.external_urls && item.external_urls.spotify"
              :href="item.external_urls.spotify"
              target="_blank"
              rel="noopener"
              class="block w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold py-2 px-4 rounded-lg transition-all duration-300 text-center"
            >
              <span class="material-icons align-middle mr-1">open_in_new</span>
              Play on Spotify
            </a>
            
            <div v-if="item.type === 'track'" class="relative">
              <button
                class="w-full bg-black/50 hover:bg-black/70 text-purple-400 font-bold py-2 px-4 rounded-lg transition-all duration-300 flex items-center justify-center border border-purple-500/30"
                @click="() => { showDropdown = showDropdown === item.id ? null : item.id }"
              >
                <span class="material-icons align-middle mr-1">playlist_add</span>
                Add to Playlist
              </button>
              
              <div
                v-if="showDropdown === item.id"
                class="absolute z-10 mt-2 w-full bg-black/90 backdrop-blur-lg border border-purple-500/30 rounded-lg shadow-xl"
              >
                <ul class="py-2">
                  <li
                    v-for="playlist in playlists"
                    :key="playlist.id"
                    class="px-4 py-3 hover:bg-purple-500/20 cursor-pointer transition-colors flex justify-between items-center"
                    @click="() => addToPlaylist(playlist.id, item.uri)"
                  >
                    <span class="text-white">{{ playlist.name }}</span>
                    <span class="text-xs text-gray-400">({{ playlist.tracks.total }} tracks)</span>
                  </li>
                  <li v-if="playlists.length === 0" class="px-4 py-3 text-gray-400">
                    No playlists available
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div v-else-if="searchQuery" class="text-center py-12 text-gray-400 bg-black/30 backdrop-blur-lg rounded-xl">
        No results found for "{{ searchQuery }}"
      </div>
    </div>
  </div>
</template>

<style>
.btn-spotify {
  background-color: #22c55e;
  color: white;
  font-weight: bold;
  padding: 0.5rem 1rem;
  border-radius: 9999px;
  transition: background-color 200ms ease-in-out;
  box-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
}

.btn-spotify:hover {
  background-color: #16a34a;
}
</style>