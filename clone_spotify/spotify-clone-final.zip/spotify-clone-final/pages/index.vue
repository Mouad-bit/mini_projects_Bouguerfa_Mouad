<template>
  <div class="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-900 via-purple-900 to-black">
    <div class="text-center p-8 rounded-2xl bg-black/30 backdrop-blur-lg shadow-2xl transform hover:scale-105 transition-all duration-300">
      <h1 class="text-5xl font-bold mb-8 bg-gradient-to-r from-purple-400 to-pink-600 text-transparent bg-clip-text">MusicFlow</h1>
      <div v-if="authStore.isAuthenticated" class="space-y-4">
        <p class="text-xl text-gray-300">Welcome back, <span class="text-purple-400 font-semibold">{{ authStore.user?.display_name }}</span></p>
        <img 
          v-if="authStore.user?.images?.[0]?.url" 
          :src="authStore.user.images[0].url" 
          alt="Profile" 
          class="mx-auto rounded-full w-24 h-24 mb-4 ring-4 ring-purple-500/50 hover:ring-purple-500 transition-all duration-300" 
        />
        <button 
          @click="logout" 
          class="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold py-3 px-8 rounded-full transition-all duration-300 transform hover:scale-105"
        >
          Sign Out
        </button>
      </div>
      <div v-else>
        <p class="text-xl text-gray-300 mb-6">Your Personal Music Journey Awaits</p>
        <button
          @click="login"
          class="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold py-3 px-8 rounded-full transition-all duration-300 transform hover:scale-105"
        >
          Connect with Spotify
        </button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
const config = useRuntimeConfig()
const authStore = useAuthStore()

const login = () => {
  const scope = [
    'user-read-email',
    'user-read-private',
    'user-read-playback-state',
    'user-modify-playback-state',
    'user-read-currently-playing',
    'user-read-recently-played',
    'user-top-read',
    'playlist-read-private',
    'playlist-read-collaborative',
    'playlist-modify-public',
    'playlist-modify-private',
    'streaming'
  ].join(' ')

  const params = new URLSearchParams({
    client_id: config.public.spotifyClientId,
    response_type: 'code',
    redirect_uri: config.public.spotifyRedirectUri,
    scope
  })

  window.location.href = `https://accounts.spotify.com/authorize?${params.toString()}`
}

const logout = () => {
  authStore.logout()
  window.location.reload()
}
</script>