<template>
  <div class="min-h-screen bg-black text-white">
    <NuxtLayout>
      <NuxtPage />
    </NuxtLayout>
  </div>
</template>

<script setup lang="ts">
// App level setup
</script>

<style>
body {
  @apply bg-black text-white;
}
</style>
