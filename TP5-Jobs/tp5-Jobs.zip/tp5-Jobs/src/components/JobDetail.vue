<template>
  <div>
    <h1>{{ job.title }}</h1>
    <p>{{ job.description }}</p>
    <p>Salary: {{ job.salary }}</p>
    <button @click="editJob(job.id)">Edit</button>
    <button @click="deleteJob(job.id)">Delete</button>
  </div>
</template>

<script>
export default {
  props: {
    jobs: {
      type: Array,
      required: true,
    },
    id: {
      type: String,
      required: true,
    },
  },
  data() {
    return {
      job: this.jobs.filter((obj) => obj.id == this.id)[0],
    };
  },
  methods: {
    editJob(id) {
      this.$router.push(`/jobs/edit/${id}`);
    },
    deleteJob(id) {
      if (confirm("Are you sure you want to delete this job?")) {
        this.$emit("delete-job", id);
        this.$router.push("/");
      }
    },
  },
};
</script>
