<template>
  <div>
    <h1>Add New Job</h1>
    <form @submit.prevent="addJob">
      <label>Title:</label>
      <input v-model="title" required />
      <label>Description:</label>
      <textarea v-model="description" required rows="1"></textarea>
      <label>Salary:</label>
      <input v-model="salary" required />
      <button type="submit" @click="addJob">Add Job</button>
    </form>
  </div>
</template>

<script>
export default {
  props: {
    jobs: {
      type: Array,
      required: true,
    },
  },
  data() {
    return {
      title: "",
      description: "",
      salary: "",
    };
  },
  methods: {
    addJob() {
      const newJob = {
        id: this.jobs.length + 1,
        title: this.title,
        description: this.description,
        salary: this.salary,
      };
      this.$emit("add-jobs", newJob);
      this.$router.push("/");
    },
  },
};
</script>
