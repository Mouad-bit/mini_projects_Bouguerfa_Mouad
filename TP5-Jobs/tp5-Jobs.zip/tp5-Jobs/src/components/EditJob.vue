<template>
  <div>
    <h1>Edit Job</h1>
    <form @submit.prevent="updateJob">
      <label>Title:</label>
      <input v-model="job.title" required />
      <label>Description:</label>
      <textarea v-model="job.description" required></textarea>
      <label>Salary:</label>
      <input v-model="job.salary" required />
      <button type="submit">Update Job</button>
    </form>
  </div>
</template>

<script>
export default {
  props: {
    jobs: {
      type: Array,
      required: true,
    },
    id: {
      type: String,
      required: true,
    },
  },
  data() {
    return {
      job: this.jobs.find((obj) => obj.id == this.id),
    };
  },
  methods: {
    updateJob() {
      this.$emit("update-jobs", this.job); // Emit the updated job to the parent
      this.$router.push("/"); // Redirect to the home page
    },
  },
};
</script>
