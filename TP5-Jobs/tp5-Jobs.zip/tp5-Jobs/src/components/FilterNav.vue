<!-- computed: {
    piecesFiltreesEtTriees() {
        let piecesFiltrees = this.pieces.filter(piece => {
            return (piece.categorie.indexOf(this.categorie) >= 0 || this.categorie === '') && (piece.nom.indexOf(this.filtrePiece) >= 0 || this.filtrePiece === '');
        });

        if (this.filtrePrix === 'croissant') {
            piecesFiltrees.sort((a, b) => a.prix - b.prix);
        } else if (this.filtrePrix === 'décroissant') {
            piecesFiltrees.sort((a, b) => b.prix - a.prix);
        }

        return piecesFiltrees;
    }
}, -->

<!-- mounted() {
    fetch('http://localhost:3000/jobs')
    .then((resp) => resp.json()) //WE GET A RESPONSE AUTOMATICALLY WHICH WE GET AS AN ARGUMENT
                                // since there is one argument we can get of the () and only keep resp
    .then((data) => this.jobs = data)
    .catch((err) => console.log(err))
} -->
