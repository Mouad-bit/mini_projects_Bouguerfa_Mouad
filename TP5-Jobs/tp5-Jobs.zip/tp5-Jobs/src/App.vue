<template>
  <div>
    <router-view
      :jobs="jobs"
      @update-jobs="updateJobs"
      @delete-job="deleteJob"
      @add-jobs="addJob"
    />
  </div>
</template>

<script>
export default {
  data() {
    return {
      jobs: [],
    };
  },
  methods: {
    updateJobs(updatedJob) {
      for (let i = 0; i < this.jobs.length; i++) {
        if (this.jobs[i].id == updatedJob.id) {
          this.jobs[i] = updatedJob;
          return;
        }
      }
    },
    deleteJob(id) {
      this.jobs = this.jobs.filter((job) => job.id !== id);
    },
    addJob(newJob) {
      this.jobs.push(newJob);
    },
  },
  mounted() {
    fetch("http://localhost:3000/jobs")
      .then((resp) => resp.json())
      .then((data) => (this.jobs = data))
      .catch((err) => console.log(err));
  },
};
</script>
