<template>
  <div>
    <h1>Job Listings</h1>
    <ul>
      <li v-for="job in jobs" :key="job.id" @click="viewJobDetail(job.id)">
        {{ job.title }} - {{ job.salary }}
      </li>
    </ul>
    <button @click="goToAddJob" class="addButton">Add New Job</button>
  </div>
</template>

<script>
export default {
  props: {
    jobs: {
      type: Array,
      required: true,
    },
  },
  methods: {
    goToAddJob() {
      this.$router.push("/add");
    },
    viewJobDetail(id) {
      this.$router.push(`/jobs/${id}`);
    },
  },
};
</script>
<style scoped>
.addButton {
  margin-left: 60px;
  margin-top: 20px;
  padding: 10px 20px;
  border: none;
  border-radius: 10px;
  background-color: black;
  color: white;
}
</style>
