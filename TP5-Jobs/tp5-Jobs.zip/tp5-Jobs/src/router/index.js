import { createRouter, createWebHistory } from "vue-router";
import Home from "../views/HomePage.vue";
import AddJob from "../components/AddJob.vue";
import EditJob from "../components/EditJob.vue";
import JobDetail from "../components/JobDetail.vue";

const routes = [
  { path: "/", component: Home, props: true }, // Pass props to Home
  { path: "/add", component: AddJob, props: true }, // Pass props to AddJob
  { path: "/jobs/:id", component: JobDetail, props: true }, // Pass props to JobDetail
  { path: "/jobs/edit/:id", component: EditJob, props: true }, // Pass props to EditJob
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
