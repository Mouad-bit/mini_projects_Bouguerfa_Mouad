<template>
  <PostList :blogs="blogs" />
</template>

<script>
import PostList from "../components/PostList.vue";

export default {
  components: { PostList },
  props: {
    blogs: {
      type: Array,
      required: true,
    },
  },
};
</script>
