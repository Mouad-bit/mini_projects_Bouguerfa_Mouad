<template>
  <div id="card">
    <div id="post-card">
      <div id="container">
        <div>
          <h2>{{ blog.title }}</h2>
        </div>
        <div><b>Tags: </b>{{ blog.tags.join(", ") }}</div>
        <br />
        <div>
          {{ blog.body }}
        </div>
      </div>

      <div id="buttons">
        <div>
          <router-link :to="{ name: 'edit', params: { id: blog.id } }"
            >Edit</router-link
          >
        </div>

        <div><router-link :to="{ name: 'home' }">Back</router-link></div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    id: {
      type: String,
      required: true,
    },
    blogs: {
      type: Array,
      required: true,
    },
  },
  data() {
    return {
      blog: this.blogs.filter((obj) => obj.id == this.id)[0],
    };
  },
};
</script>

<style scoped>
#post-card {
  width: 100vh;
  background: white;
  border-radius: 8px;
  padding: 0.8rem 1rem;
  margin-top: 20px;
  margin-bottom: 10px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  transition: transform 0.2s;
}

#buttons {
  display: flex;
  justify-content: space-around;
  gap: 30px;
  margin: 20px;
}

#buttons a {
  text-decoration: none;
  color: white;
  background-color: black;
  padding: 0.5rem 0.8rem;
  border-radius: 5px;
}

#container a {
  text-decoration: none;
  color: gray;
}

#container a:hover {
  text-decoration: underline;
}
</style>
