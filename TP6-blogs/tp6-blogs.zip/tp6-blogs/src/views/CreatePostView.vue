<template>
  <div>
    <form @submit.prevent="addPost" id="container">
      <div>
        <label>Title: </label>
        <input type="text" v-model="title" required />
      </div>

      <div>
        <label>Body: </label>
        <textarea v-model="body" required></textarea>
      </div>

      <div>
        <label>Tags: </label>
        <input
          type="text"
          v-model="inputTags"
          placeholder="Enter values, separated by commas"
          required
        />
      </div>

      <div><button type="submit">AddPost</button></div>
    </form>
  </div>
</template>

<script>
export default {
  props: {
    blogs: {
      type: Array,
      required: true,
    },
  },
  data() {
    return {
      title: "",
      body: "",
      inputTags: "",
      tags: [],
    };
  },
  methods: {
    addPost() {
      // create tags list
      if (this.inputTags.trim()) {
        this.tags = this.inputTags
          .split(",")
          .map((item) => item.trim())
          .filter((item) => item != "");
      }

      const newPost = {
        id: this.blogs.length + 1,
        title: this.title,
        body: this.body,
        tags: this.tags,
      };
      this.$emit("add-post", newPost);
      this.$router.push("/");
    },
  },
};
</script>

<style>
#container {
  display: flex;
  flex-direction: column;
  gap: 20px;
  padding: 1.5rem 3rem;
}

#container div {
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
}

#container div input {
  width: 250px;
  margin-left: 20px;
}

#container div label {
  font-size: 18px;
  font-weight: 400;
}

#container div textarea {
  width: 250px;
  margin-left: 18px;
  height: 200px;
}

#container button {
  width: 100px;
  height: 25px;
  margin-left: 15%;
}
</style>
