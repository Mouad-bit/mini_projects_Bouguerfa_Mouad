<template>
  <div>
    <div v-for="blog in tagsList" :key="blog.id" class="post-card">
      <SinglePost :blog="blog" />
    </div>
  </div>
</template>

<script>
import SinglePost from "@/components/SinglePost.vue";

export default {
  components: { SinglePost },
  props: {
    tag: {
      type: String,
      required: true,
    },
    blogs: {
      type: Array,
      required: true,
    },
  },
  data() {
    return {
      tagsList: [],
    };
  },
  created() {
    for (const blog of this.blogs) {
      for (const tag of blog.tags) {
        if (tag == this.tag) {
          this.tagsList.push(blog);
        }
      }
    }
  },
};
</script>

<style scoped>
.post-card {
  width: 100vh;
  background: white;
  border-radius: 8px;
  padding: 0.5rem 1rem;
  margin-bottom: 10px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  transition: transform 0.2s;
}

.post-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
}
</style>
