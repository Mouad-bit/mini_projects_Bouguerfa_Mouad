<template>
  <div>
    <form @submit.prevent="UpdatePost" id="container">
      <div>
        <label>Title: </label>
        <input type="text" v-model="title" />
      </div>

      <div>
        <label>Body: </label>
        <textarea v-model="body"></textarea>
      </div>

      <div>
        <label>Tags: </label>
        <input
          type="text"
          v-model="inputTags"
          placeholder="Enter values, separated by commas"
        />
      </div>

      <div><button type="submit">Update</button></div>
    </form>
  </div>
</template>

<script>
export default {
  props: {
    id: {
      type: String,
      resuired: true,
    },
    blogs: {
      type: Array,
      required: true,
    },
  },
  data() {
    return {
      blog: null,
      title: "",
      body: "",
      inputTags: "",
    };
  },
  computed: {
    formattedTags() {
      if (!this.inputTags.trim()) return [];
      return this.inputTags
        .split(",")
        .map((tag) => tag.trim())
        .filter((tag) => tag !== "");
    },
  },
  methods: {
    UpdatePost() {
      const newPost = {
        id: this.blog.id,
        title: this.title,
        body: this.body,
        tags: this.formattedTags,
      };
      this.$emit("update-post", newPost);
      this.$router.push("/");
    },
  },
  created() {
    this.blog = this.blogs.find((obj) => obj.id == this.id);
    if (this.blog) {
      this.title = this.blog.title;
      this.body = this.blog.body;
      this.inputTags = this.blog.tags.join(", ");
    }
  },
};
</script>

<style scoped>
#container {
  display: flex;
  flex-direction: column;
  gap: 20px;
  padding: 1.5rem 3rem;
}

#container div {
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
}

#container div input {
  width: 250px;
  margin-left: 20px;
}

#container div label {
  font-size: 18px;
  font-weight: 400;
}

#container div textarea {
  width: 250px;
  margin-left: 18px;
  height: 200px;
}

#container button {
  width: 100px;
  height: 25px;
  margin-left: 15%;
}
</style>
