<template>
  <NavBar />
  <router-view :blogs="blogs" @add-post="addPost" @update-post="UpdatePost" />
</template>

<script>
import NavBar from "./components/NavBar.vue";

export default {
  components: { NavBar },
  data() {
    return {
      blogs: [],
    };
  },
  mounted() {
    fetch("http://localhost:3000/blogs")
      .then((resp) => resp.json())
      .then((data) => (this.blogs = data))
      .catch((err) => console.log(err));
  },
  methods: {
    async addPost(newPost) {
      await fetch("http://localhost:3000/blogs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newPost),
      });

      // fetching existing tags
      const existingTags = await fetch("http://localhost:3000/tags").then(
        (res) => res.json()
      );

      // adding new tags
      for (let tag of newPost.tags) {
        if (
          !existingTags.some(
            (obj) => obj.name.toLowerCase() == tag.toLowerCase()
          )
        ) {
          await fetch("http://localhost:3000/tags", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name: tag }),
          });
        }
      }
    },
    async UpdatePost(newPost) {
      await fetch(`http://localhost:3000/blogs/${newPost.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newPost),
      });
    },
  },
};
</script>

<style></style>
