<template>
  <div class="post-list-container">
    <div class="posts-column">
      <div>
        <div v-for="blog in blogs" :key="blog.id" class="post-card">
          <SinglePost :blog="blog" />
        </div>
      </div>
      <div>
        <TagCloud />
      </div>
    </div>
  </div>
</template>

<script>
import SinglePost from "../components/SinglePost.vue";
import TagCloud from "../components/TagCloud.vue";

export default {
  components: {
    SinglePost,
    TagCloud,
  },
  props: {
    blogs: {
      type: Array,
      required: true,
    },
  },
};
</script>

<style scoped>
.post-list-container {
  display: flex;
  gap: 2rem;
  margin: 0 auto;
  padding: 2rem;
}

.posts-column {
  display: flex;
  gap: 1.5rem;
}

.post-card {
  width: 100vh;
  background: white;
  border-radius: 8px;
  padding: 0.5rem 1rem;
  margin-bottom: 10px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  transition: transform 0.2s;
}

.post-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
}
</style>
