<template>
  <div class="tag-cloud">
    <router-link
      v-for="tag in tags"
      :key="tag.name"
      :to="{ name: 'tags', params: { tag: tag.name } }"
    >
      #{{ tag.name }}
    </router-link>
  </div>
</template>

<script>
export default {
  data() {
    return {
      tags: [],
    };
  },
  mounted() {
    fetch("http://localhost:3000/tags")
      .then((res) => res.json())
      .then((data) => (this.tags = data))
      .catch((err) => console.log(err));
  },
};
</script>

<style scoped>
#tagsList {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}
.tag-cloud {
  display: flex;
  flex-direction: column;
  gap: 15px;
}
.tag-cloud a {
  margin-left: 20px;
  text-decoration: none;
  color: black;
  font-size: 20px;
  font-weight: 700;
}
</style>
