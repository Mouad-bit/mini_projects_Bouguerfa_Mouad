<template>
  <div id="container">
    <div>
      <h2>{{ blog.title }}</h2>
    </div>
    <div><b>Tags: </b>{{ blog.tags.join(", ") }}</div>
    <br />
    <div>
      {{ blog.body.substring(0, 50) }}....
      <router-link :to="{ name: 'details', params: { id: blog.id } }"
        >more details</router-link
      >
    </div>
  </div>
</template>

<script>
export default {
  props: {
    blog: {
      type: Object,
      required: true,
    },
  },
  computed: {
    formattedTags() {
      if (!this.blog.tags) return "";
      return this.blog.tags.join(", ");
    },
  },
};
</script>

<style scoped>
#container a {
  text-decoration: none;
  color: gray;
}

#container a:hover {
  text-decoration: underline;
}
</style>
