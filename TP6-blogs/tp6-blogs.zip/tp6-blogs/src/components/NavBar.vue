<template>
  <div id="navBar">
    <div><router-link :to="{ name: 'home' }">Home</router-link></div>
    <div><router-link :to="{ name: 'add' }">AddPost</router-link></div>
  </div>
</template>

<style scoped>
#navBar {
  display: flex;
  flex-direction: row;
  justify-content: center;
}
#navBar div {
  margin-left: 50px;
}
#navBar a {
  text-decoration: none;
  font-size: 20px;
  font-weight: 800;
  color: black;
}
</style>
