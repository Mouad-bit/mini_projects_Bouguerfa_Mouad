import { createRouter, createWebHistory } from "vue-router";
import HomeView from "../views/HomeView.vue";
import PostDetail from "../views/PostDetailView.vue";
import AddPost from "../views/CreatePostView.vue";
import EditPost from "../views/EditPost.vue";
import TagsView from "../views/TagsPostView.vue";

const routes = [
  {
    path: "/",
    name: "home",
    component: HomeView,
  },
  {
    path: "/details/:id",
    name: "details",
    component: PostDetail,
    props: true,
  },
  {
    path: "/add",
    name: "add",
    component: AddPost,
  },
  {
    path: "/edit/:id",
    name: "edit",
    component: EditPost,
    props: true,
  },
  {
    path: "/tags/:tag",
    name: "tags",
    component: TagsView,
    props: true,
  },
];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
});

export default router;
